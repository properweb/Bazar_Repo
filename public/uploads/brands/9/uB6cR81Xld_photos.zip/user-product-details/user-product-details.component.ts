import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-product-details',
  templateUrl: './user-product-details.component.html',
  styleUrls: ['./user-product-details.component.css']
})
export class UserProductDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
