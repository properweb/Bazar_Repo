<?php include "header.php";




define('SERVER_DB_HOST', '107.180.68.182');
define('SERVER_DB_USER', 'gravitys_server');
define('SERVER_DB_PASS', 'Admin123!');
define('SERVER_DB_NAME', 'gravitys_server'); 
$sdbc=mysql_connect(SERVER_DB_HOST,SERVER_DB_USER,SERVER_DB_PASS) or die("Unable to connect to the database...");
mysql_select_db(SERVER_DB_NAME,$sdbc) or die("Unable to select the database...");

define('GC_DB_HOST', '107.180.68.182');
define('GC_DB_USER', 'ikasco');
define('GC_DB_PASS', 'ABpgf_8Rv6{t');
define('GC_DB_NAME', 'ikasco_inventory'); 
$kdbc=mysql_connect(GC_DB_HOST,GC_DB_USER,GC_DB_PASS) or die("Unable to connect to the database...");
mysql_select_db(GC_DB_NAME,$kdbc) or die("Unable to select the database...");
		
define('LOCAL_DB_HOST', 'localhost');
define('LOCAL_DB_USER', 'root');
define('LOCAL_DB_PASS', '');
define('LOCAL_DB_NAME', 'gravity_pos');
$dbc = mysql_connect(LOCAL_DB_HOST, LOCAL_DB_USER, LOCAL_DB_PASS) or die("Unable to connect to the database...");
mysql_select_db(LOCAL_DB_NAME, $dbc) or die("Unable to select the database...");
date_default_timezone_set("Jordan/Amman");
		



 $qry_pay1 = "SELECT * FROM sales_table_item WHERE all_update =1  AND store_id='".$_SESSION['store_id']."'";
	        $res_pay1 = mysql_query($qry_pay1,$dbc);
			$numrows1 = mysql_num_rows($res_pay1);
			if($numrows1>0)
			{
			
			$qry_sttt11 = "SELECT store_no FROM store_table WHERE store_id='" . $_SESSION['store_id'] . "'";
			$res_stt11 = mysql_query($qry_sttt11,$dbc);
			$row_stt11 = mysql_fetch_array($res_stt11);
			
				$qry_in = "SELECT sl_no FROM posted_table";
				$res_in = mysql_query($qry_in,$dbc);
				$row_in = mysql_fetch_array($res_in);
				$num_in = mysql_num_rows($res_in);
				if($num_in>0)
				{
					 $sl_no = $row_in['sl_no'] + 1;
					 
				}
				else
				{
					$sl_no = 1;
				}
				
				
		$qry_post = "SELECT sale_date FROM `sales_table_item` WHERE company_id='".$_SESSION['company_id']."' AND all_update=1 AND store_id='".$_SESSION['store_id']."' ORDER BY sale_date ASC LIMIT 0,1";
		$res_post = mysql_query($qry_post,$dbc);
		$row_post = mysql_fetch_array($res_post);
		$posted_date = str_replace("-","",$row_post['sale_date']);
		$invoice_no = 'GS' . $row_stt11['store_no'] . $posted_date . $sl_no;
		
		
			/////////////////////////////////////////////////// Gravity Sale /////////////////////////////////////////////////////////////////////////////////
		
		
		$qry_up2 = "UPDATE account_product_table SET status=0,posted_type=0 WHERE all_update =1 AND company='".$_SESSION['company_id']."' AND store_id='".$_SESSION['store_id']."' AND trans_type='Sale'";
		mysql_query($qry_up2,$dbc);
		
		
		$qry_sale_item = "SELECT * FROM account_product_table WHERE all_update =1 AND company='".$_SESSION['company_id']."' AND store_id='".$_SESSION['store_id']."' AND trans_type='Sale'";
				$res_sale_item = mysql_query($qry_sale_item,$dbc);
				while($row_sale_item = mysql_fetch_assoc($res_sale_item))
					{  
						$a = '';
						$a_cal = '';
						$a_val = '';
						$b = '';
						$c = 0;
			
				foreach ($row_sale_item as $col_s => $val_s)
				{
					if($a=='')
					{
						///////////////////////////////
						$a_cal = $col_s;
						$a_val = $val_s;
						 
							$a = "INSERT INTO `account_product_table` SET ";
						
					}
					else
					{
						if($c == 0)
						{
							
							$a .= " `".$col_s."`='".$val_s."'";
							$c = 1;
						}
						else
						{
							if($col_s=='transaction_no')
							{
								$a .= ",`".$col_s."`='".$invoice_no."'";
							}
							else if($col_s=='transaction_date')
							{
								$a .= ",`".$col_s."`='".$row_post['sale_date']."'";
							}
							else
							{
							$a .= ",`".$col_s."`='".$val_s."'";
							}
						}
					}
				}
				$c++;
				
			mysql_query($a,$sdbc);
			
		}
		
		
		
		
		$qry_g_sale = "SELECT * FROM sales_table_item WHERE company_id='".$_SESSION['company_id']."' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_sale = mysql_query($qry_g_sale,$dbc);
		$sub_total = 0;
        $total = 0;
        $total_tax = 0;
        $s_t_6 = 0;
        $s_t_7 = 0;
		while($row_g_sale = mysql_fetch_array($res_g_sale))
		{
			
            $sub_total = number_format($sub_total + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']), 3, '.', '');
            // $total = number_format($total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty'])),3, '.', '');
			if($row_g_sale['qty']>0)
			{
             $total_tax = number_format(($total_tax + ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
			else
			{
				$total_tax = number_format(($total_tax - ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
            $total = $total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty']));
            ////////////////////////
            $product_id = $row_g_sale['product_id'];
            $query_5 = "SELECT * FROM  `product_table` WHERE product_id = " . $product_id;
            $result_5 = mysql_query($query_5,$dbc);
            $row_5 = mysql_fetch_array($result_5);
            $Adv_flag = $row_5['Adv_flag'];
            if ($Adv_flag == 6) 
			{
                $s_t_6 = $s_t_6 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
            } 
			else if ($Adv_flag == 7)
			 {
                $s_t_7 = $s_t_7 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
             }
		}
		$dis_sister = "SELECT `sister` FROM distributor_tbl WHERE company='" . $_SESSION['company_id'] . "'";
		$res_sister = mysql_query($dis_sister,$dbc);
		$row_sister = mysql_fetch_array($res_sister);
		
		
		$qry_loc = "SELECT * FROM `sister_account` WHERE store_id='" . $_SESSION['store_id'] . "' AND sister='N'";
		$res_loc = mysql_query($qry_loc,$dbc);
		$row_loc = mysql_fetch_array($res_loc);
		
		$qry_loc2 = "SELECT id FROM `test_inventory_table` WHERE old_location='" . $row_loc['location'] . "'";
		$res_loc2 = mysql_query($qry_loc2,$dbc);
		$row_loc2 = mysql_fetch_array($res_loc2);
		

        $qry_get_acc = "SELECT * FROM sister_account WHERE sister='" . $row_sister['sister'] . "' AND store_id='" . $_SESSION['store_id'] . "' AND location LIKE '%" . $row_loc['location'] . "%'";
        $res_get_acc = mysql_query($qry_get_acc,$dbc);
        $row_get_acc = mysql_fetch_array($res_get_acc);

        $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['sales_customer_account'] . "' || old_account='" . $row_get_acc['sales_customer_account'] . "'";
        $res_acc = mysql_query($qry_acc,$dbc);
        $row_7 = mysql_fetch_array($res_acc);

       /* $acc_no = $row_7['account_no_format'];
        $acc_id = $row_7['account_tree_id'];
        $acc_name = $row_7['account_eng'];*/
		
		$qry_pos_accnt = "SELECT s.`pos_cus_account`,a.`account_no_format`,a.`account_eng`,a.`account_tree_id` FROM `store_cons_account_tbl` as s JOIN `acoount_tree_table` as a ON `s`.`pos_cus_account`=`a`.`account_no_format` WHERE s.`store_id`='" . $_SESSION['store_id'] . "' AND s.`company_id`='" . $_SESSION['company_id'] . "'";
    $res_pos_accnt = mysql_query($qry_pos_accnt,$dbc);
    $row_pos_accnt = mysql_fetch_array($res_pos_accnt);

    $acc_no = mysql_real_escape_string($row_pos_accnt['account_no_format']);
    $acc_id = mysql_real_escape_string($row_pos_accnt['account_tree_id']);
    $acc_name = mysql_real_escape_string($row_pos_accnt['account_eng']);
		
		
		 $query_2 = "INSERT INTO `sales_table` SET `invoice_no`='" . $invoice_no . "',`store_id`='" . $_SESSION['store_id'] . "',`sale_date`='" . $row_post['sale_date'] . "',`currency`='JOD',`taxable`='Yes',`acc_no`='" . $acc_no . "',`acc_id`='" . $acc_id . "',`acc_name`='" . $acc_name . "',`location`='" . $row_loc2['id'] . "',`sale_person`='" . $row_8['store_manager'] . "',`sub_total`='" . $sub_total . "',`tax_total`='" . $total_tax . "',`grand_total`='" . ($sub_total + $total_tax) . "',`prepared_by`='".$_SESSION['Gen_ID']."',`prepared_date`='".$row_post['sale_date']."',`approve_by`='".$_SESSION['Gen_ID']."',`approve_date`='".$row_post['sale_date']."',`posted_by`='".$_SESSION['Gen_ID']."',`posted_date`='".$row_post['sale_date']."',`credit_limit`='',`credit_balance`='',`unpaid_cheques`='',`FOC_Goods`='',`FOC_Advertising`='',`Goods`='" . $s_t_6 . "',`Paid_Advertising`='" . $s_t_7 . "',`company_id`='" . $_SESSION['company_id'] . "',`userid`='" . $row_8['customer_no'] . "',`consignment`='',`chain_id`='',`sale_date_time`='" . $row_post['sale_date'] . "',`type`='POS',`status`=0,`new_status`='1',all_update =0,from_c=8";
            mysql_query($query_2,$sdbc);
            $sales_id = mysql_insert_id($sdbc);
			
			$qry_g_insert = "SELECT * FROM sales_table_item WHERE company_id='".$_SESSION['company_id']."' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_insert = mysql_query($qry_g_insert,$dbc);
		while($row_4 = mysql_fetch_array($res_g_insert))
			{
				  $insert_sale_item = "INSERT INTO `sales_table_item` SET `sales_id`='" . $sales_id . "',`product_id`='" . $row_4['product_id'] . "',`product_no`='" . $row_4['product_no'] . "',`title`='" . $row_4['title'] . "',`category`='" . $row_4['category'] . "',`tax`='" . $row_4['tax'] . "',`discount`='" . $row_4['discount'] . "',`qty`='" . $row_4['qty'] . "',`rec_qty`='" . $row_4['qty'] . "',`adv`='" . $row_4['adv'] . "',`retail_price`='" . $row_4['retail_price'] . "',`wholesale_price`='" . $row_4['wholesale_price'] . "',`total`='" . $row_4['total'] . "',`sales_person`='" . $row_4['sales_person'] . "',`sales_person_id`='" . $row_4['sales_person_id'] . "',`store_id`='" . $row_4['store_id'] . "',`company_id`='" . $_SESSION['company_id'] . "',`acc_no`='" . $row_4['acc_no'] . "',`acc_id`='" . $row_4['acc_id'] . "',`location`='" . $row_4['location'] . "',`brand`='" . $row_4['brand'] . "',`supplier`='" . $row_4['supplier'] . "',`post`=1,`brand_id`='" . $row_4['brand_id'] . "',`supplier_id`='" . $row_4['supplier_id'] . "',`brand_code`='" . $row_4['brand_code'] . "',`supp_code`='" . $row_4['supp_code'] . "',`posted_date`='" . $row_post['sale_date'] . "',`barcode`='" . $row_4['barcode'] . "',`ref_no`='" . $row_4['ref_no'] . "',`sub_store`='" . $row_4['sub_store'] . "',`chain_id`='" . $row_4['chain_id'] . "',`transaction_no`='" . $invoice_no . "',`type`='" . $row_4['type'] . "',`main_cat_id`='" . $row_4['main_cat_id'] . "',`division`='" . $row_4['division'] . "',`distributor`='" . $row_4['distributor'] . "',`payment_type`='" . $row_4['payment_type'] . "',`status`=0,`card_no`='" . $row_4['card_no'] . "',`card_type`='" . $row_4['card_type'] . "',`cat_id`='" . $row_4['cat_id'] . "',`sub_cat_id`='" . $row_4['sub_cat_id'] . "',`func_flag`='" . $row_4['func_flag'] . "',`sale_date_time`='" . $row_post['sale_date'] . "',`sale_date`='" . $row_post['sale_date'] . "',`discount_price`='" . $row_4['discount_price'] . "',`tax_price`='" . $row_4['tax_price'] . "',`from_company`='" . $row_4['from_company'] . "',`old_invoice`='" . $row_4['old_invoice'] . "',`unit_price_wot`='" . $row_4['unit_price_wot'] . "',`unit_price_wt`='" . $row_4['unit_price_wt'] . "',`Custmr_Dscnt`='" . $row_4['Custmr_Dscnt'] . "',`Custmr_Dscnt_Value`='" . $row_4['Custmr_Dscnt_Value'] . "',`Invest`='" . $row_4['Invest'] . "',`Invest_Disc_Value_WT`='" . $row_4['Invest_Disc_Value_WT'] . "',`Extra_Dscn_per`='" . $row_4['Extra_Dscn_per'] . "',`Extra_Dscnt_Value_WT`='" . $row_4['Extra_Dscnt_Value_WT'] . "',`Notes`='" . $row_4['Notes'] . "',`posting_date`='" . $row_4['posting_date'] . "',`store_manager`='" . $row_4['store_manager'] . "',`customer_name`='" . $row_4['customer_name'] . "',`customer_no`='" . $row_4['customer_no'] . "',`new_status`='" . $row_4['new_status'] . "',phone='" . $row_4['phone'] . "',rand_pur='" . $row_4['rand_pur'] . "',tax_free='" . $tax_frrr . "',all_update =0,sub_invoice='".$row_4['transaction_no']."'";
				
				 mysql_query($insert_sale_item,$sdbc);
			}
			
			
			
			
        $qry_get_acc = "SELECT * FROM store_cons_account_tbl WHERE   store_id='" . $_SESSION['store_id'] . "' AND company_id='" . $_SESSION['company_id'] . "'";
        $res_get_acc = mysql_query($qry_get_acc,$dbc);
        $row_get_acc = mysql_fetch_array($res_get_acc);

        $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_sale_account'] . "' || old_account='" . $row_get_acc['pos_sale_account'] . "'";

        $res_acc = mysql_query($qry_acc,$dbc);
        $row_7 = mysql_fetch_array($res_acc);

        $pos_sale_account = $row_7['account_no_format'];
        //$acc_id = $row_7['account_tree_id'];
        $pos_sale_account_name = $row_7['account_eng'];

        ///////////
        if ($row_get_acc['invesment_acc'] != '') {
            $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['invesment_acc'] . "' || old_account='" . $row_get_acc['invesment_acc'] . "'";

            $res_acc = mysql_query($qry_acc,$dbc);
            $row_7 = mysql_fetch_array($res_acc);

            $invesment_acc = $row_7['account_no_format'];
            //$acc_id = $row_7['account_tree_id'];
            $invesment_acc_name = $row_7['account_eng'];
        }
        $qry_acc1 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_tax_account'] . "' || old_account='" . $row_get_acc['pos_tax_account'] . "'";
        $res_acc1 = mysql_query($qry_acc1,$dbc);
        $row_8 = mysql_fetch_array($res_acc1);
        $pos_tax_account = $row_8['account_no_format'];
        $pos_tax_account_name = $row_8['account_eng'];
        $qry_acc2 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_cus_account'] . "' || old_account='" . $row_get_acc['pos_cus_account'] . "'";
        $res_acc2 = mysql_query($qry_acc2,$dbc);
        $row_8 = mysql_fetch_array($res_acc2);
        $pos_cus_account = $row_8['account_no_format'];
        $pos_cus_account_name = $row_8['account_eng'];
		$qry_cur = "SELECT * FROM currency_table WHERE currency='JOD'";
		$res_cur = mysql_query($qry_cur,$dbc);
		$row_cur = mysql_fetch_array($res_cur);
		$decimal_value = $row_cur['decimal_value'];
		$sale_account_debit = number_format($sub_total, $decimal_value, '.', '');
		$consignment_tax_Account_debit = number_format($total_tax, $decimal_value, '.', '');
		$Supp_Account_credit = number_format($sub_total + $total_tax, $decimal_value, '.', '');

		$qry_sttt11 = "SELECT * FROM store_table WHERE store_id='" . $_SESSION['store_id'] . "'";
		$res_stt11 = mysql_query($qry_sttt11,$dbc);
		$row_stt11 = mysql_fetch_array($res_stt11);
		$inv_account_credit = $sub_total * $row_stt11['invs_per'] / 100;

		$qry_rate = "SELECT * FROM comapny_currency_table WHERE currency_id='" . $row_cur['id'] . "'";
		$res_rate = mysql_query($qry_rate,$dbc);
		$row_rate = mysql_fetch_array($res_rate);
         
		  

		$currency_rate = 1;
		$sale_account_base_debit = number_format(($sub_total * $currency_rate), $decimal_value, '.', '');
		$consignment_tax_Account_base_debit = number_format(($total_tax * $currency_rate), $decimal_value, '.', '');
		$total = $sale_account_base_debit + $consignment_tax_Account_base_debit;
		$Supp_Account_base_credit = number_format(($total * $currency_rate), $decimal_value, '.', '');
		
		
		$qry_tran = "INSERT INTO account_transaction_table SET trans_type='Sale',trans_no='" . $invoice_no . "',trans_date='" . $row_post['sale_date'] . "',company='" . $_SESSION['company_id'] . "',account_no='" . $pos_sale_account . "',store_id='" . $_SESSION['store_id'] . "',location='" . $row_loc2['id'] . "',`pos_type`='pos'";
    mysql_query($qry_tran,$sdbc);
    $id = mysql_insert_id($sdbc);

    $qry_tran_acc = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_sale_account . "',account_name='" . $pos_sale_account_name . "',short_desc='" . $invoice_no . "',debit='" . $sale_account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_debit='" . $Supp_Account_credit . "',trans_date='" . $row_post['sale_date'] . "',company='" . $_SESSION['company_id'] . "',location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos',debit1='" . $sale_account_debit . "',base_debit1='" . $Supp_Account_credit . "'";
    mysql_query($qry_tran_acc,$sdbc);

    $qry_tran_acc1 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_tax_account . "',account_name='" . $pos_tax_account_name . "',short_desc='" . $invoice_no . "',credit='" . $consignment_tax_Account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $consignment_tax_Account_base_debit . "',trans_date='" . $row_post['sale_date'] . "',company='" . $_SESSION['company_id'] . "',location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos',credit1='" . $consignment_tax_Account_debit . "',base_credit1='" . $consignment_tax_Account_base_debit . "'";
    mysql_query($qry_tran_acc1,$sdbc);


    $qry_tran_acc2 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_cus_account . "',account_name='" . $pos_cus_account_name . "',short_desc='" . $invoice_no . "',credit='" . $total . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $Supp_Account_base_credit . "',trans_date='" . $row_post['sale_date'] . "',company='" . $_SESSION['company_id'] . "',location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos',credit1='" . $total . "',base_credit1='" . $Supp_Account_base_credit . "'";
    mysql_query($qry_tran_acc2,$sdbc);
   /* if ($row_get_acc['invesment_acc'] != '') {
        $qry_tran_acc3 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $invesment_acc . "',account_name='" . $invesment_acc_name . "',short_desc='" . $invoice_no . "',credit='" . $inv_account_credit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $inv_account_credit . "',trans_date='" . $row_post['sale_date'] . "',company='" . $_SESSION['company_id'] . "',location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale'";
        mysql_query($qry_tran_acc3,$sdbc);
    }*/
	
	
	/////////////////////////////////////////////////// Gravity Sale /////////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
    	/////////////////////////////////////////////////// Gravity Purchase /////////////////////////////////////////////////////////////////////////////////
		
		
		$invoice_no = 'GP' . $row_stt11['store_no'] . $posted_date . $sl_no;
		
		
		$qry_up2 = "UPDATE account_product_table SET status=0,posted_type=0 WHERE all_update =1 AND company='".$_SESSION['company_id']."' AND store_id='".$_SESSION['store_id']."' AND trans_type='Purchase'";
		mysql_query($qry_up2,$dbc);
		
		
		$qry_sale_item = "SELECT * FROM account_product_table WHERE all_update =1 AND company='".$_SESSION['company_id']."' AND store_id='".$_SESSION['store_id']."' AND trans_type='Purchase'";
				$res_sale_item = mysql_query($qry_sale_item,$dbc);
				while($row_sale_item = mysql_fetch_assoc($res_sale_item))
					{  
						$a = '';
						$a_cal = '';
						$a_val = '';
						$b = '';
						$c = 0;
			
				foreach ($row_sale_item as $col_s => $val_s)
				{
					if($a=='')
					{
						///////////////////////////////
						$a_cal = $col_s;
						$a_val = $val_s;
						 
							$a = "INSERT INTO `account_product_table` SET ";
						
					}
					else
					{
						if($c == 0)
						{
							
							$a .= " `".$col_s."`='".$val_s."'";
							$c = 1;
						}
						else
						{
							if($col_s=='transaction_no')
							{
								$a .= ",`".$col_s."`='".$invoice_no."'";
							}
							else if($col_s=='transaction_date')
							{
								$a .= ",`".$col_s."`='".$row_post['sale_date']."'";
							}
							else
							{
							$a .= ",`".$col_s."`='".$val_s."'";
							}
						}
					}
				}
				$c++;
				
			mysql_query($a,$sdbc);
			
		}
		
		
		
		
		$qry_g_sale = "SELECT * FROM  purchase_table_item WHERE company_id='".$_SESSION['company_id']."' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_sale = mysql_query($qry_g_sale,$dbc);
		$num_g_sale = mysql_num_rows($res_g_sale);
		$sub_total = 0;
        $total = 0;
        $total_tax = 0;
        $s_t_6 = 0;
        $s_t_7 = 0;
		if($num_g_sale>0)
		{
		while($row_g_sale = mysql_fetch_array($res_g_sale))
		{
			
            $sub_total = number_format($sub_total + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']), 3, '.', '');
            // $total = number_format($total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty'])),3, '.', '');
			if($row_g_sale['qty']>0)
			{
             $total_tax = number_format(($total_tax + ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
			else
			{
				$total_tax = number_format(($total_tax - ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
            $total = $total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty']));
            ////////////////////////
            $product_id = $row_g_sale['product_id'];
            $query_5 = "SELECT * FROM  `product_table` WHERE product_id = " . $product_id;
            $result_5 = mysql_query($query_5,$dbc);
            $row_5 = mysql_fetch_array($result_5);
            $Adv_flag = $row_5['Adv_flag'];
            if ($Adv_flag == 6) 
			{
                $s_t_6 = $s_t_6 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
            } 
			else if ($Adv_flag == 7)
			 {
                $s_t_7 = $s_t_7 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
             }
		}
		$dis_sister = "SELECT `sister` FROM distributor_tbl WHERE company='" . $_SESSION['company_id'] . "'";
		$res_sister = mysql_query($dis_sister,$dbc);
		$row_sister = mysql_fetch_array($res_sister);
		
		
		$qry_loc = "SELECT * FROM `sister_account` WHERE store_id='" . $_SESSION['store_id'] . "' AND sister='N'";
		$res_loc = mysql_query($qry_loc,$dbc);
		$row_loc = mysql_fetch_array($res_loc);
		
		$qry_loc2 = "SELECT id FROM `test_inventory_table` WHERE old_location='" . $row_loc['location'] . "'";
		$res_loc2 = mysql_query($qry_loc2,$dbc);
		$row_loc2 = mysql_fetch_array($res_loc2);
		

        $qry_get_acc = "SELECT * FROM sister_account WHERE sister='" . $row_sister['sister'] . "' AND store_id='" . $_SESSION['store_id'] . "' AND location LIKE '%" . $row_loc['location'] . "%'";
        $res_get_acc = mysql_query($qry_get_acc,$dbc);
        $row_get_acc = mysql_fetch_array($res_get_acc);

       $qry_acc1 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['purchase_customer_account'] . "' || old_account='" . $row_get_acc['purchase_customer_account'] . "'";
        $res_acc1 = mysql_query($qry_acc1);
        $row_acc1 = mysql_fetch_array($res_acc1);

        $acc_no = $row_acc1['account_no_format'];
        $acc_id = $row_acc1['account_tree_id'];
        $acc_name = $row_acc1['account_eng'];
		
		
		
		 $query_2 = "INSERT INTO `purchase_table` SET `supp_invoice_no`='" . $invoice_no . "',`store_id`='" . $_SESSION['store_id'] . "',`purchase_date`='" . $row_post['sale_date'] . "',`currency`='JOD',`taxable`='Yes',`acc_no`='" . $acc_no . "',`acc_id`='" . $acc_id . "',`acc_name`='" . $acc_name . "',`prepared_by`='" . $_SESSION['Gen_ID'] . "',`sub_total`='" . $sub_total . "',`tax_total`='" . $total_tax . "',`grand_total`='" . ($sub_total + $total_tax) . "',`prepared_date`='" . $row_post['sale_date'] . "',`approve_by`='" . $_SESSION['Gen_ID'] . "',`approve_date`='" . $row_post['sale_date'] . "',`posted_by`='" . $_SESSION['Gen_ID'] . "',`credit_limit`='',`credit_balance`='',`unpaid_cheques`='',`FOC_Goods`='',`FOC_Advertising`='',`Goods`='" . $s_t_6 . "',`Paid_Advertising`='" . $s_t_7 . "',`company_id`='" . $_SESSION['company_id'] . "',`userid`='" . $row_8['customer_no'] . "',`consignment`='',`trans_type`='Purchase',`status`=0,`new_status`=0,slno='" . $slno . "',purchase_no='" . $invoice_no . "',posted_date='" . $row_post['sale_date'] . "',all_update =0";
            mysql_query($query_2,$sdbc);
            $purchase_id = mysql_insert_id($sdbc);
			
			$qry_g_insert = "SELECT * FROM  purchase_table_item WHERE company_id='".$_SESSION['company_id']."' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_insert = mysql_query($qry_g_insert,$dbc);
		while($row_4 = mysql_fetch_array($res_g_insert))
			{
				   $insert_purchase_item = "INSERT INTO `purchase_table_item` SET `purchase_id`='".$purchase_id."',`product_id`='" . $row_4['product_id'] . "',`product_no`='" . $row_4['product_no'] . "',`title`='" . $row_4['title'] . "',`category`='" . $row_4['category'] . "',`tax`='" . $row_4['tax'] . "',`discount`='" . $row_4['discount'] . "',`qty`='" . $row_4['qty'] . "',`rec_qty`='" . $row_4['qty'] . "',`adv`='" . $row_4['adv'] . "',`retail_price`='" . $row_4['retail_price'] . "',`wholesale_price`='" . $row_4['wholesale_price'] . "',`total`='" . $row_4['total'] . "',`store_id`='" . $row_4['store_id'] . "',`company_id`='" . $_SESSION['company_id'] . "',`patch`='',`acc_no`='" . $row_acc1['account_no_format'] . "',`acc_id`='" . $row_acc1['account_tree_id'] . "',`brand`='" . $row_4['brand'] . "',`supplier`='" . $row_4['supplier'] . "',`post`=1,`brand_id`='" . $row_4['brand_id'] . "',`supplier_id`='" . $row_4['supplier_id'] . "',`brand_code`='" . $row_4['brand_code'] . "',`supp_code`='" . $row_4['supp_code'] . "',`posted_date`='" . $row_post['sale_date'] . "',`sub_store`='" . $row_4['sub_store'] . "',`barcode`='" . $row_4['barcode'] . "',`ref_no`='" . $row_4['ref_no'] . "',`transaction_no`='" . $invoice_no . "',`main_cat_id`='" . $row_4['main_cat_id'] . "',`cat_id`='" . $row_4['cat_id'] . "',`sub_cat_id`='" . $row_4['sub_cat_id'] . "',`purchase_date`='" . $row_post['sale_date'] . "',`new_status`=0,rand_pur = '" . $ran . "',all_update =0,sub_invoice='".$row_4['transaction_no']."'";
				 
				 mysql_query($insert_purchase_item,$sdbc);
			}
			
			
			
			
       $dis_sister = "SELECT `sister` FROM distributor_tbl WHERE company='" . $_SESSION['company_id'] . "'";
    $res_sister = mysql_query($dis_sister,$dbc);
    $row_sister = mysql_fetch_array($res_sister);



    $qry_get_acc = "SELECT * FROM sister_account WHERE sister='N' AND store_id='" . $_SESSION['store_id'] . "' AND location LIKE '%" . $row_loc['location'] . "%'";
  
    $res_get_acc = mysql_query($qry_get_acc,$dbc);
    $row_get_acc = mysql_fetch_array($res_get_acc);

    $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['purchase_customer_account'] . "' || old_account='" . $row_get_acc['purchase_customer_account'] . "'";

    $res_acc = mysql_query($qry_acc,$dbc);
    $row_7 = mysql_fetch_array($res_acc);

    $purchase_customer_account = $row_7['account_no_format'];
    //$acc_id = $row_7['account_tree_id'];
    $purchase_customer_account_name = $row_7['account_eng'];


    $qry_acc1 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['purchase_tax_account'] . "' || old_account='" . $row_get_acc['purchase_tax_account'] . "'";

    $res_acc1 = mysql_query($qry_acc1,$dbc);
    $row_8 = mysql_fetch_array($res_acc1);

    $purchase_tax_account = $row_8['account_no_format'];
    //$acc_id = $row_7['account_tree_id'];
    $purchase_tax_account_name = $row_8['account_eng'];

    $qry_acc2 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['purchase_account'] . "' || old_account='" . $row_get_acc['purchase_account'] . "'";

    $res_acc2 = mysql_query($qry_acc2,$dbc);
    $row_8 = mysql_fetch_array($res_acc2);

    $purchase_account = $row_8['account_no_format'];
    //$acc_id = $row_7['account_tree_id'];
    $purchase_account_name = $row_8['account_eng'];

    $qry_cur = "SELECT * FROM currency_table WHERE currency='" . $currency . "'";
    $res_cur = mysql_query($qry_cur);
    $row_cur = mysql_fetch_array($res_cur);

    $decimal_value = $row_cur['decimal_value'];



    $purchase_account_debit = number_format($sub_total, $decimal_value, '.', '');
    $consignment_tax_Account_debit = number_format($total_tax, $decimal_value, '.', '');
    $Supp_Account_credit = number_format($sub_total + $total_tax, $decimal_value, '.', '');



    $qry_rate = "SELECT * FROM comapny_currency_table WHERE currency_id='" . $row_cur['id'] . "' AND company_id='" . $_SESSION['company_id'] . "'";
    $res_rate = mysql_query($qry_rate,$dbc);
    $row_rate = mysql_fetch_array($res_rate);


    $currency_rate = 1;
    $purchase_account_base_debit = number_format(($sub_total * $currency_rate), $decimal_value, '.', '');
    $consignment_tax_Account_base_debit = number_format(($total_tax * $currency_rate), $decimal_value, '.', '');
	$total = $sub_total + $total_tax;
    $Supp_Account_base_credit = number_format(($total * $currency_rate), $decimal_value, '.', '');
    
	$trans_type = 'Purchase';
	$trans_no = $invoice_no;
	$trans_date = $row_post['sale_date'];
	$store_id = $_SESSION['store_id'];

    ///////////////////////////////////////////////////
    $qry_tran = "INSERT INTO account_transaction_table SET trans_type='" . $trans_type . "',trans_no='" . $trans_no . "',trans_date='" . $trans_date . "',company='" . $_SESSION['company_id'] . "',account_no='" . $purchase_customer_account . "',store_id='" . $store_id . "',location='" . $row_loc2['id'] . "',`pos_type`='pos',all_update =0";
    mysql_query($qry_tran,$sdbc);
    $id = mysql_insert_id($sdbc);

    $qry_tran_acc = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $purchase_customer_account . "',account_name='" . $purchase_customer_account_name . "',short_desc='" . $trans_no . "',debit='" . $purchase_account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_debit='" . $purchase_account_base_debit . "',trans_date='" . $trans_date . "',company='" . $_SESSION['company_id'] . "',location='" . $row_loc2['id'] . "',store_id='" . $store_id . "',trans_type='" . $trans_type . "',all_update =0,`pos_type`='pos',debit1='" . $purchase_account_debit . "'',base_debit1='" . $purchase_account_base_debit . "'";
    mysql_query($qry_tran_acc,$sdbc);

    $qry_tran_acc1 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $purchase_tax_account . "',account_name='" . $purchase_tax_account_name . "',short_desc='" . $trans_no . "',debit='" . $total_tax . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_debit='" . $total_tax . "',trans_date='" . $trans_date . "',company='" . $_SESSION['company_id'] . "',location='" . $row_loc2['id'] . "',store_id='" . $store_id . "',trans_type='" . $trans_type . "',all_update =0,`pos_type`='pos',debit1='" . $total_tax . "',base_debit1='" . $total_tax . "'";
    mysql_query($qry_tran_acc1,$sdbc);


    $qry_tran_acc2 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $purchase_account . "',account_name='" . $purchase_account_name . "',short_desc='" . $trans_no . "',credit='" . $total . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $total . "',trans_date='" . $trans_date . "',company='" . $_SESSION['company_id'] . "',location='" . $row_loc2['id'] . "',store_id='" . $store_id . "',trans_type='" . $trans_type . "',all_update =0,`pos_type`='pos',credit1='" . $total . "',base_credit1='" . $total . "'";
    mysql_query($qry_tran_acc2,$sdbc);
	
	
	/////////////////////////////////////////////////// Gravity Purchase /////////////////////////////////////////////////////////////////////////////////
			
		}
		
		
		
		
		/////////////////////////////////////////////////// ITE Purchase /////////////////////////////////////////////////////////////////////////////////
		
		
		$invoice_no = 'GP' . $row_stt11['store_no'] . $posted_date . $sl_no.'_4';
		
		
		$qry_up2 = "UPDATE account_product_table SET status=0,posted_type=0 WHERE all_update =1 AND company='4' AND store_id='".$_SESSION['store_id']."' AND trans_type='Purchase'";
		mysql_query($qry_up2,$dbc);
		
		
		$qry_sale_item = "SELECT * FROM account_product_table WHERE all_update =1 AND company='4' AND store_id='".$_SESSION['store_id']."' AND trans_type='Purchase'";
				$res_sale_item = mysql_query($qry_sale_item,$dbc);
				while($row_sale_item = mysql_fetch_assoc($res_sale_item))
					{  
						$a = '';
						$a_cal = '';
						$a_val = '';
						$b = '';
						$c = 0;
			
				foreach ($row_sale_item as $col_s => $val_s)
				{
					if($a=='')
					{
						///////////////////////////////
						$a_cal = $col_s;
						$a_val = $val_s;
						 
							$a = "INSERT INTO `account_product_table` SET ";
						
					}
					else
					{
						if($c == 0)
						{
							
							$a .= " `".$col_s."`='".$val_s."'";
							$c = 1;
						}
						else
						{
							if($col_s=='transaction_no')
							{
								$a .= ",`".$col_s."`='".$invoice_no."'";
							}
							else if($col_s=='transaction_date')
							{
								$a .= ",`".$col_s."`='".$row_post['sale_date']."'";
							}
							else
							{
							$a .= ",`".$col_s."`='".$val_s."'";
							}
						}
					}
				}
				$c++;
				
			mysql_query($a,$kdbc);
			
		}
		
		
		
		
		$qry_g_sale = "SELECT * FROM  purchase_table_item WHERE company_id='4' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_sale = mysql_query($qry_g_sale,$dbc);
		$num_g_sale = mysql_num_rows($res_g_sale);
		$sub_total = 0;
        $total = 0;
        $total_tax = 0;
        $s_t_6 = 0;
        $s_t_7 = 0;
		if($num_g_sale>0)
		{
		while($row_g_sale = mysql_fetch_array($res_g_sale))
		{
			
            $sub_total = number_format($sub_total + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']), 3, '.', '');
            // $total = number_format($total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty'])),3, '.', '');
			if($row_g_sale['qty']>0)
			{
             $total_tax = number_format(($total_tax + ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
			else
			{
				$total_tax = number_format(($total_tax - ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
            $total = $total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty']));
            ////////////////////////
            $product_id = $row_g_sale['product_no'];
            $query_5 = "SELECT * FROM  `product_table` WHERE product_no = '".$product_id."'";
            $result_5 = mysql_query($query_5,$dbc);
            $row_5 = mysql_fetch_array($result_5);
            $Adv_flag = $row_5['Adv_flag'];
            if ($Adv_flag == 6) 
			{
                $s_t_6 = $s_t_6 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
            } 
			else if ($Adv_flag == 7)
			 {
                $s_t_7 = $s_t_7 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
             }
		}
		$dis_sister = "SELECT `sister` FROM distributor_tbl WHERE company='4'";
		$res_sister = mysql_query($dis_sister,$dbc);
		$row_sister = mysql_fetch_array($res_sister);
		
		
		$qry_loc = "SELECT * FROM `sister_account` WHERE store_id='" . $_SESSION['store_id'] . "' AND sister='N'";
		$res_loc = mysql_query($qry_loc,$dbc);
		$row_loc = mysql_fetch_array($res_loc);
		
		$qry_loc2 = "SELECT id FROM `test_inventory_table` WHERE old_location='" . $row_loc['location'] . "'";
		$res_loc2 = mysql_query($qry_loc2,$dbc);
		$row_loc2 = mysql_fetch_array($res_loc2);
		

        $qry_get_acc = "SELECT * FROM sister_account WHERE sister='" . $row_sister['sister'] . "' AND store_id='" . $_SESSION['store_id'] . "' AND location LIKE '%" . $row_loc['location'] . "%'";
        $res_get_acc = mysql_query($qry_get_acc,$dbc);
        $row_get_acc = mysql_fetch_array($res_get_acc);

       $qry_acc1 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['purchase_customer_account'] . "' || old_account='" . $row_get_acc['purchase_customer_account'] . "'";
        $res_acc1 = mysql_query($qry_acc1);
        $row_acc1 = mysql_fetch_array($res_acc1);

        $acc_no = $row_acc1['account_no_format'];
        $acc_id = $row_acc1['account_tree_id'];
        $acc_name = $row_acc1['account_eng'];
		
		
		
		 $query_2 = "INSERT INTO `purchase_table` SET `supp_invoice_no`='" . $invoice_no . "',`store_id`='" . $_SESSION['store_id'] . "',`purchase_date`='" . $row_post['sale_date'] . "',`currency`='JOD',`taxable`='Yes',`acc_no`='" . $acc_no . "',`acc_id`='" . $acc_id . "',`acc_name`='" . $acc_name . "',`prepared_by`='" . $_SESSION['Gen_ID'] . "',`sub_total`='" . $sub_total . "',`tax_total`='" . $total_tax . "',`grand_total`='" . ($sub_total + $total_tax) . "',`prepared_date`='" . $row_post['sale_date'] . "',`approve_by`='" . $_SESSION['Gen_ID'] . "',`approve_date`='" . $row_post['sale_date'] . "',`posted_by`='" . $_SESSION['Gen_ID'] . "',`credit_limit`='',`credit_balance`='',`unpaid_cheques`='',`FOC_Goods`='',`FOC_Advertising`='',`Goods`='" . $s_t_6 . "',`Paid_Advertising`='" . $s_t_7 . "',`company_id`='4',`userid`='" . $row_8['customer_no'] . "',`consignment`='',`trans_type`='Purchase',`status`=0,`new_status`=0,slno='" . $slno . "',purchase_no='" . $invoice_no . "',posted_date='" . $row_post['sale_date'] . "',all_update =0";
            mysql_query($query_2,$kdbc);
            $purchase_id = mysql_insert_id($kdbc);
			
			$qry_g_insert = "SELECT * FROM  purchase_table_item WHERE company_id='4' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_insert = mysql_query($qry_g_insert,$dbc);
		while($row_4 = mysql_fetch_array($res_g_insert))
			{
				   $insert_purchase_item = "INSERT INTO `purchase_table_item` SET `purchase_id`='".$purchase_id."',`product_id`='" . $row_4['product_id'] . "',`product_no`='" . $row_4['product_no'] . "',`title`='" . $row_4['title'] . "',`category`='" . $row_4['category'] . "',`tax`='" . $row_4['tax'] . "',`discount`='" . $row_4['discount'] . "',`qty`='" . $row_4['qty'] . "',`rec_qty`='" . $row_4['qty'] . "',`adv`='" . $row_4['adv'] . "',`retail_price`='" . $row_4['retail_price'] . "',`wholesale_price`='" . $row_4['wholesale_price'] . "',`total`='" . $row_4['total'] . "',`store_id`='" . $row_4['store_id'] . "',`company_id`='4',`patch`='',`acc_no`='" . $row_acc1['account_no_format'] . "',`acc_id`='" . $row_acc1['account_tree_id'] . "',`brand`='" . $row_4['brand'] . "',`supplier`='" . $row_4['supplier'] . "',`post`=1,`brand_id`='" . $row_4['brand_id'] . "',`supplier_id`='" . $row_4['supplier_id'] . "',`brand_code`='" . $row_4['brand_code'] . "',`supp_code`='" . $row_4['supp_code'] . "',`posted_date`='" . $row_post['sale_date'] . "',`sub_store`='" . $row_4['sub_store'] . "',`barcode`='" . $row_4['barcode'] . "',`ref_no`='" . $row_4['ref_no'] . "',`transaction_no`='" . $invoice_no . "',`main_cat_id`='" . $row_4['main_cat_id'] . "',`cat_id`='" . $row_4['cat_id'] . "',`sub_cat_id`='" . $row_4['sub_cat_id'] . "',`purchase_date`='" . $row_post['sale_date'] . "',`new_status`=0,rand_pur = '" . $ran . "',all_update =0,sub_invoice='".$row_4['transaction_no']."'";
				 
				 mysql_query($insert_purchase_item,$kdbc);
			}
			
			
			
			
       $dis_sister = "SELECT `sister` FROM distributor_tbl WHERE company='4'";
    $res_sister = mysql_query($dis_sister,$dbc);
    $row_sister = mysql_fetch_array($res_sister);



    $qry_get_acc = "SELECT * FROM sister_account WHERE sister='N' AND store_id='" . $_SESSION['store_id'] . "' AND location LIKE '%" . $row_loc['location'] . "%'";
  
    $res_get_acc = mysql_query($qry_get_acc,$dbc);
    $row_get_acc = mysql_fetch_array($res_get_acc);

    $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['purchase_customer_account'] . "' || old_account='" . $row_get_acc['purchase_customer_account'] . "'";

    $res_acc = mysql_query($qry_acc,$dbc);
    $row_7 = mysql_fetch_array($res_acc);

    $purchase_customer_account = $row_7['account_no_format'];
    //$acc_id = $row_7['account_tree_id'];
    $purchase_customer_account_name = $row_7['account_eng'];


    $qry_acc1 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['purchase_tax_account'] . "' || old_account='" . $row_get_acc['purchase_tax_account'] . "'";

    $res_acc1 = mysql_query($qry_acc1,$dbc);
    $row_8 = mysql_fetch_array($res_acc1);

    $purchase_tax_account = $row_8['account_no_format'];
    //$acc_id = $row_7['account_tree_id'];
    $purchase_tax_account_name = $row_8['account_eng'];

    $qry_acc2 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['purchase_account'] . "' || old_account='" . $row_get_acc['purchase_account'] . "'";

    $res_acc2 = mysql_query($qry_acc2,$dbc);
    $row_8 = mysql_fetch_array($res_acc2);

    $purchase_account = $row_8['account_no_format'];
    //$acc_id = $row_7['account_tree_id'];
    $purchase_account_name = $row_8['account_eng'];

    $qry_cur = "SELECT * FROM currency_table WHERE currency='" . $currency . "'";
    $res_cur = mysql_query($qry_cur);
    $row_cur = mysql_fetch_array($res_cur);

    $decimal_value = $row_cur['decimal_value'];



    $purchase_account_debit = number_format($sub_total, $decimal_value, '.', '');
    $consignment_tax_Account_debit = number_format($total_tax, $decimal_value, '.', '');
    $Supp_Account_credit = number_format($sub_total + $total_tax, $decimal_value, '.', '');



    $qry_rate = "SELECT * FROM comapny_currency_table WHERE currency_id='" . $row_cur['id'] . "' AND company_id='4'";
    $res_rate = mysql_query($qry_rate,$dbc);
    $row_rate = mysql_fetch_array($res_rate);


    $currency_rate = 1;
    $purchase_account_base_debit = number_format(($sub_total * $currency_rate), $decimal_value, '.', '');
    $consignment_tax_Account_base_debit = number_format(($total_tax * $currency_rate), $decimal_value, '.', '');
	$total = $sub_total + $total_tax;
    $Supp_Account_base_credit = number_format(($total * $currency_rate), $decimal_value, '.', '');
    
	//$invoice_no = 
	$trans_type = 'Purchase';
	 $trans_no = $invoice_no;
	
	$trans_date = $row_post['sale_date'];
	$store_id = $_SESSION['store_id'];

    ///////////////////////////////////////////////////
    $qry_tran = "INSERT INTO account_transaction_table SET trans_type='" . $trans_type . "',trans_no='" . $trans_no . "',trans_date='" . $trans_date . "',company='4',account_no='" . $purchase_customer_account . "',store_id='" . $store_id . "',location='" . $row_loc2['id'] . "',`pos_type`='pos',all_update =0";
    mysql_query($qry_tran,$kdbc);
    $id = mysql_insert_id($kdbc);

    $qry_tran_acc = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $purchase_customer_account . "',account_name='" . $purchase_customer_account_name . "',short_desc='" . $trans_no . "',debit='" . $purchase_account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_debit='" . $purchase_account_base_debit . "',trans_date='" . $trans_date . "',company='4',location='" . $row_loc2['id'] . "',store_id='" . $store_id . "',trans_type='" . $trans_type . "',all_update =0,`pos_type`='pos',debit1='" . $purchase_account_debit . "',base_debit1='" . $purchase_account_base_debit . "'";
    mysql_query($qry_tran_acc,$kdbc);

    $qry_tran_acc1 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $purchase_tax_account . "',account_name='" . $purchase_tax_account_name . "',short_desc='" . $trans_no . "',debit='" . $consignment_tax_Account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_debit='" . $consignment_tax_Account_base_debit . "',trans_date='" . $trans_date . "',company='4',location='" . $row_loc2['id'] . "',store_id='" . $store_id . "',trans_type='" . $trans_type . "',all_update =0,`pos_type`='pos',debit1='" . $consignment_tax_Account_debit . "',base_debit1='" . $consignment_tax_Account_base_debit . "'";
    mysql_query($qry_tran_acc1,$kdbc);


    $qry_tran_acc2 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $purchase_account . "',account_name='" . $purchase_account_name . "',short_desc='" . $trans_no . "',credit='" . $total . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $Supp_Account_base_credit . "',trans_date='" . $trans_date . "',company='4',location='" . $row_loc2['id'] . "',store_id='" . $store_id . "',trans_type='" . $trans_type . "',all_update =0,`pos_type`='pos',credit1='" . $total . "',base_credit1='" . $Supp_Account_base_credit . "'";
    mysql_query($qry_tran_acc2,$kdbc);
	
	
	/////////////////////////////////////////////////// ITE Purchase /////////////////////////////////////////////////////////////////////////////////
			
		}
		
		
		
		/////////////////////////////////////////////////// ITE Sale /////////////////////////////////////////////////////////////////////////////////
		
		
		$invoice_no = 'GS' . $row_stt11['store_no'] . $posted_date . $sl_no.'_4';
		
		$qry_up2 = "UPDATE account_product_table SET status=0,posted_type=0 WHERE all_update =1 AND company='4' AND store_id='".$_SESSION['store_id']."' AND trans_type='Sale'";
		mysql_query($qry_up2,$dbc);
		
		
		$qry_sale_item = "SELECT * FROM account_product_table WHERE all_update =1 AND company='4' AND store_id='".$_SESSION['store_id']."' AND trans_type='Sale'";
				$res_sale_item = mysql_query($qry_sale_item,$dbc);
				while($row_sale_item = mysql_fetch_assoc($res_sale_item))
					{  
						$a = '';
						$a_cal = '';
						$a_val = '';
						$b = '';
						$c = 0;
			
				foreach ($row_sale_item as $col_s => $val_s)
				{
					if($a=='')
					{
						///////////////////////////////
						$a_cal = $col_s;
						$a_val = $val_s;
						 
							$a = "INSERT INTO `account_product_table` SET ";
						
					}
					else
					{
						if($c == 0)
						{
							
							$a .= " `".$col_s."`='".$val_s."'";
							$c = 1;
						}
						else
						{
							if($col_s=='transaction_no')
							{
								$a .= ",`".$col_s."`='".$invoice_no."'";
							}
							else if($col_s=='transaction_date')
							{
								$a .= ",`".$col_s."`='".$row_post['sale_date']."'";
							}
							else
							{
							$a .= ",`".$col_s."`='".$val_s."'";
							}
						}
					}
				}
				$c++;
				
			mysql_query($a,$kdbc);
			
		}
		
		
		
		
		$qry_g_sale = "SELECT * FROM sales_table_item WHERE company_id='4' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_sale = mysql_query($qry_g_sale,$dbc);
		$sub_total = 0;
        $total = 0;
        $total_tax = 0;
        $s_t_6 = 0;
        $s_t_7 = 0;
		while($row_g_sale = mysql_fetch_array($res_g_sale))
		{
			
            $sub_total = number_format($sub_total + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']), 3, '.', '');
            // $total = number_format($total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty'])),3, '.', '');
			if($row_g_sale['qty']>0)
			{
             $total_tax = number_format(($total_tax + ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
			else
			{
				$total_tax = number_format(($total_tax - ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
            $total = $total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty']));
            ////////////////////////
            $product_id = $row_g_sale['product_no'];
            $query_5 = "SELECT * FROM  `product_table` WHERE product_no = '".$product_id."'";
            $result_5 = mysql_query($query_5,$dbc);
            $row_5 = mysql_fetch_array($result_5);
            $Adv_flag = $row_5['Adv_flag'];
            if ($Adv_flag == 6) 
			{
                $s_t_6 = $s_t_6 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
            } 
			else if ($Adv_flag == 7)
			 {
                $s_t_7 = $s_t_7 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
             }
		}
		$dis_sister = "SELECT `sister` FROM distributor_tbl WHERE company='4'";
		$res_sister = mysql_query($dis_sister,$dbc);
		$row_sister = mysql_fetch_array($res_sister);
		
		
		$qry_loc = "SELECT * FROM `sister_account` WHERE store_id='" . $_SESSION['store_id'] . "' AND sister='N'";
		$res_loc = mysql_query($qry_loc,$dbc);
		$row_loc = mysql_fetch_array($res_loc);
		
		$qry_loc2 = "SELECT id FROM `test_inventory_table` WHERE old_location='" . $row_loc['location'] . "'";
		$res_loc2 = mysql_query($qry_loc2,$dbc);
		$row_loc2 = mysql_fetch_array($res_loc2);
		

        $qry_get_acc = "SELECT * FROM sister_account WHERE sister='" . $row_sister['sister'] . "' AND store_id='" . $_SESSION['store_id'] . "' AND location LIKE '%" . $row_loc['location'] . "%'";
        $res_get_acc = mysql_query($qry_get_acc,$dbc);
        $row_get_acc = mysql_fetch_array($res_get_acc);

        $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['sales_customer_account'] . "' || old_account='" . $row_get_acc['sales_customer_account'] . "'";
        $res_acc = mysql_query($qry_acc,$dbc);
        $row_7 = mysql_fetch_array($res_acc);

       /* $acc_no = $row_7['account_no_format'];
        $acc_id = $row_7['account_tree_id'];
        $acc_name = $row_7['account_eng'];*/
		
		$qry_pos_accnt = "SELECT s.`pos_cus_account`,a.`account_no_format`,a.`account_eng`,a.`account_tree_id` FROM `store_cons_account_tbl` as s JOIN `acoount_tree_table` as a ON `s`.`pos_cus_account`=`a`.`account_no_format` WHERE s.`store_id`='" . $_SESSION['store_id'] . "' AND s.`company_id`='4'";
    $res_pos_accnt = mysql_query($qry_pos_accnt,$dbc);
    $row_pos_accnt = mysql_fetch_array($res_pos_accnt);

    $acc_no = mysql_real_escape_string($row_pos_accnt['account_no_format']);
    $acc_id = mysql_real_escape_string($row_pos_accnt['account_tree_id']);
    $acc_name = mysql_real_escape_string($row_pos_accnt['account_eng']);
		
		
		 $query_2 = "INSERT INTO `sales_table` SET `invoice_no`='" . $invoice_no . "',`store_id`='" . $_SESSION['store_id'] . "',`sale_date`='" . $row_post['sale_date'] . "',`currency`='JOD',`taxable`='Yes',`acc_no`='" . $acc_no . "',`acc_id`='" . $acc_id . "',`acc_name`='" . $acc_name . "',`location`='" . $row_loc2['id'] . "',`sale_person`='" . $row_8['store_manager'] . "',`sub_total`='" . $sub_total . "',`tax_total`='" . $total_tax . "',`grand_total`='" . ($sub_total + $total_tax) . "',`prepared_by`='".$_SESSION['Gen_ID']."',`prepared_date`='".$row_post['sale_date']."',`approve_by`='".$_SESSION['Gen_ID']."',`approve_date`='".$row_post['sale_date']."',`posted_by`='".$_SESSION['Gen_ID']."',`posted_date`='".$row_post['sale_date']."',`credit_limit`='',`credit_balance`='',`unpaid_cheques`='',`FOC_Goods`='',`FOC_Advertising`='',`Goods`='" . $s_t_6 . "',`Paid_Advertising`='" . $s_t_7 . "',`company_id`=4,`userid`='" . $row_8['customer_no'] . "',`consignment`='',`chain_id`='',`sale_date_time`='" . $row_post['sale_date'] . "',`type`='POS',`status`=0,`new_status`='1',all_update =0,from_c=8";
            mysql_query($query_2,$kdbc);
            $sales_id = mysql_insert_id($kdbc);
			
			$qry_g_insert = "SELECT * FROM sales_table_item WHERE company_id='4' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_insert = mysql_query($qry_g_insert,$dbc);
		while($row_4 = mysql_fetch_array($res_g_insert))
			{
				  $insert_sale_item = "INSERT INTO `sales_table_item` SET `sales_id`='" . $sales_id . "',`product_id`='" . $row_4['product_id'] . "',`product_no`='" . $row_4['product_no'] . "',`title`='" . $row_4['title'] . "',`category`='" . $row_4['category'] . "',`tax`='" . $row_4['tax'] . "',`discount`='" . $row_4['discount'] . "',`qty`='" . $row_4['qty'] . "',`rec_qty`='" . $row_4['qty'] . "',`adv`='" . $row_4['adv'] . "',`retail_price`='" . $row_4['retail_price'] . "',`wholesale_price`='" . $row_4['wholesale_price'] . "',`total`='" . $row_4['total'] . "',`sales_person`='" . $row_4['sales_person'] . "',`sales_person_id`='" . $row_4['sales_person_id'] . "',`store_id`='" . $row_4['store_id'] . "',`company_id`=4,`acc_no`='" . $row_4['acc_no'] . "',`acc_id`='" . $row_4['acc_id'] . "',`location`='" . $row_4['location'] . "',`brand`='" . $row_4['brand'] . "',`supplier`='" . $row_4['supplier'] . "',`post`=1,`brand_id`='" . $row_4['brand_id'] . "',`supplier_id`='" . $row_4['supplier_id'] . "',`brand_code`='" . $row_4['brand_code'] . "',`supp_code`='" . $row_4['supp_code'] . "',`posted_date`='" . $row_post['sale_date'] . "',`barcode`='" . $row_4['barcode'] . "',`ref_no`='" . $row_4['ref_no'] . "',`sub_store`='" . $row_4['sub_store'] . "',`chain_id`='" . $row_4['chain_id'] . "',`transaction_no`='" . $invoice_no . "',`type`='" . $row_4['type'] . "',`main_cat_id`='" . $row_4['main_cat_id'] . "',`division`='" . $row_4['division'] . "',`distributor`='" . $row_4['distributor'] . "',`payment_type`='" . $row_4['payment_type'] . "',`status`=0,`card_no`='" . $row_4['card_no'] . "',`card_type`='" . $row_4['card_type'] . "',`cat_id`='" . $row_4['cat_id'] . "',`sub_cat_id`='" . $row_4['sub_cat_id'] . "',`func_flag`='" . $row_4['func_flag'] . "',`sale_date_time`='" . $row_post['sale_date'] . "',`sale_date`='" . $row_post['sale_date'] . "',`discount_price`='" . $row_4['discount_price'] . "',`tax_price`='" . $row_4['tax_price'] . "',`from_company`='" . $row_4['from_company'] . "',`old_invoice`='" . $row_4['old_invoice'] . "',`unit_price_wot`='" . $row_4['unit_price_wot'] . "',`unit_price_wt`='" . $row_4['unit_price_wt'] . "',`Custmr_Dscnt`='" . $row_4['Custmr_Dscnt'] . "',`Custmr_Dscnt_Value`='" . $row_4['Custmr_Dscnt_Value'] . "',`Invest`='" . $row_4['Invest'] . "',`Invest_Disc_Value_WT`='" . $row_4['Invest_Disc_Value_WT'] . "',`Extra_Dscn_per`='" . $row_4['Extra_Dscn_per'] . "',`Extra_Dscnt_Value_WT`='" . $row_4['Extra_Dscnt_Value_WT'] . "',`Notes`='" . $row_4['Notes'] . "',`posting_date`='" . $row_4['posting_date'] . "',`store_manager`='" . $row_4['store_manager'] . "',`customer_name`='" . $row_4['customer_name'] . "',`customer_no`='" . $row_4['customer_no'] . "',`new_status`='" . $row_4['new_status'] . "',phone='" . $row_4['phone'] . "',rand_pur='" . $row_4['rand_pur'] . "',tax_free='" . $tax_frrr . "',all_update =0,sub_invoice='".$row_4['transaction_no']."'";
				
				 mysql_query($insert_sale_item,$kdbc);
			}
			
			
			
			
        $qry_get_acc = "SELECT * FROM store_cons_account_tbl WHERE   store_id='" . $_SESSION['store_id'] . "' AND company_id='4'";
        $res_get_acc = mysql_query($qry_get_acc,$dbc);
        $row_get_acc = mysql_fetch_array($res_get_acc);

        $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_sale_account'] . "' || old_account='" . $row_get_acc['pos_sale_account'] . "'";

        $res_acc = mysql_query($qry_acc,$dbc);
        $row_7 = mysql_fetch_array($res_acc);

        $pos_sale_account = $row_7['account_no_format'];
        //$acc_id = $row_7['account_tree_id'];
        $pos_sale_account_name = $row_7['account_eng'];

        ///////////
        if ($row_get_acc['invesment_acc'] != '') {
            $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['invesment_acc'] . "' || old_account='" . $row_get_acc['invesment_acc'] . "'";

            $res_acc = mysql_query($qry_acc,$dbc);
            $row_7 = mysql_fetch_array($res_acc);

            $invesment_acc = $row_7['account_no_format'];
            //$acc_id = $row_7['account_tree_id'];
            $invesment_acc_name = $row_7['account_eng'];
        }
        $qry_acc1 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_tax_account'] . "' || old_account='" . $row_get_acc['pos_tax_account'] . "'";
        $res_acc1 = mysql_query($qry_acc1,$dbc);
        $row_8 = mysql_fetch_array($res_acc1);
        $pos_tax_account = $row_8['account_no_format'];
        $pos_tax_account_name = $row_8['account_eng'];
        $qry_acc2 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_cus_account'] . "' || old_account='" . $row_get_acc['pos_cus_account'] . "'";
        $res_acc2 = mysql_query($qry_acc2,$dbc);
        $row_8 = mysql_fetch_array($res_acc2);
        $pos_cus_account = $row_8['account_no_format'];
        $pos_cus_account_name = $row_8['account_eng'];
		$qry_cur = "SELECT * FROM currency_table WHERE currency='JOD'";
		$res_cur = mysql_query($qry_cur,$dbc);
		$row_cur = mysql_fetch_array($res_cur);
		$decimal_value = $row_cur['decimal_value'];
		$sale_account_debit = number_format($sub_total, $decimal_value, '.', '');
		$consignment_tax_Account_debit = number_format($total_tax, $decimal_value, '.', '');
		$Supp_Account_credit = number_format($sub_total + $total_tax, $decimal_value, '.', '');

		$qry_sttt11 = "SELECT * FROM store_table WHERE store_id='" . $_SESSION['store_id'] . "'";
		$res_stt11 = mysql_query($qry_sttt11,$dbc);
		$row_stt11 = mysql_fetch_array($res_stt11);
		$inv_account_credit = $sub_total * $row_stt11['invs_per'] / 100;

		$qry_rate = "SELECT * FROM comapny_currency_table WHERE currency_id='" . $row_cur['id'] . "'";
		$res_rate = mysql_query($qry_rate,$dbc);
		$row_rate = mysql_fetch_array($res_rate);
         
		  

		$currency_rate = 1;
		$sale_account_base_debit = number_format(($sub_total * $currency_rate), $decimal_value, '.', '');
		$consignment_tax_Account_base_debit = number_format(($total_tax * $currency_rate), $decimal_value, '.', '');
		$total = $sale_account_base_debit + $consignment_tax_Account_base_debit;
		$Supp_Account_base_credit = number_format(($total * $currency_rate), $decimal_value, '.', '');
		
		
		$qry_tran = "INSERT INTO account_transaction_table SET trans_type='Sale',trans_no='" . $invoice_no . "',trans_date='" . $row_post['sale_date'] . "',company=4,account_no='" . $pos_sale_account . "',store_id='" . $_SESSION['store_id'] . "',location='" . $row_loc2['id'] . "',`pos_type`='pos'";
    mysql_query($qry_tran,$kdbc);
    $id = mysql_insert_id($kdbc);

    $qry_tran_acc = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_sale_account . "',account_name='" . $pos_sale_account_name . "',short_desc='" . $invoice_no . "',debit='" . $sale_account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_debit='" . $Supp_Account_credit . "',trans_date='" . $row_post['sale_date'] . "',company=4,location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos',debit1='" . $sale_account_debit . "',base_debit1='" . $Supp_Account_credit . "'";
    mysql_query($qry_tran_acc,$kdbc);

    $qry_tran_acc1 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_tax_account . "',account_name='" . $pos_tax_account_name . "',short_desc='" . $invoice_no . "',credit='" . $consignment_tax_Account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $consignment_tax_Account_base_debit . "',trans_date='" . $row_post['sale_date'] . "',company=4,location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos',credit1='" . $consignment_tax_Account_debit . "',base_credit1='" . $consignment_tax_Account_base_debit . "'";
    mysql_query($qry_tran_acc1,$kdbc);


    $qry_tran_acc2 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_cus_account . "',account_name='" . $pos_cus_account_name . "',short_desc='" . $invoice_no . "',credit='" . $total . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $Supp_Account_base_credit . "',trans_date='" . $row_post['sale_date'] . "',company=4,location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos',credit1='" . $total . "',base_credit1='" . $Supp_Account_base_credit . "'";
    mysql_query($qry_tran_acc2,$kdbc);
   /* if ($row_get_acc['invesment_acc'] != '') {
        $qry_tran_acc3 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $invesment_acc . "',account_name='" . $invesment_acc_name . "',short_desc='" . $invoice_no . "',credit='" . $inv_account_credit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $inv_account_credit . "',trans_date='" . $row_post['sale_date'] . "',company=4,location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale'";
        mysql_query($qry_tran_acc3,$kdbc);
    }*/
	
	
	/////////////////////////////////////////////////// ITE Sale /////////////////////////////////////////////////////////////////////////////////
	
	
	
		/////////////////////////////////////////////////// TARAF Sale /////////////////////////////////////////////////////////////////////////////////
		
		
		$invoice_no = 'GS' . $row_stt11['store_no'] . $posted_date . $sl_no.'_9';
		
		$qry_up2 = "UPDATE account_product_table SET status=0,posted_type=0 WHERE all_update =1 AND company='9' AND store_id='".$_SESSION['store_id']."' AND trans_type='Sale'";
		mysql_query($qry_up2,$dbc);
		
		
		$qry_sale_item = "SELECT * FROM account_product_table WHERE all_update =1 AND company='9' AND store_id='".$_SESSION['store_id']."' AND trans_type='Sale'";
				$res_sale_item = mysql_query($qry_sale_item,$dbc);
				while($row_sale_item = mysql_fetch_assoc($res_sale_item))
					{  
						$a = '';
						$a_cal = '';
						$a_val = '';
						$b = '';
						$c = 0;
			
				foreach ($row_sale_item as $col_s => $val_s)
				{
					if($a=='')
					{
						///////////////////////////////
						$a_cal = $col_s;
						$a_val = $val_s;
						 
							$a = "INSERT INTO `account_product_table` SET ";
						
					}
					else
					{
						if($c == 0)
						{
							
							$a .= " `".$col_s."`='".$val_s."'";
							$c = 1;
						}
						else
						{
							if($col_s=='transaction_no')
							{
								$a .= ",`".$col_s."`='".$invoice_no."'";
							}
							else if($col_s=='transaction_date')
							{
								$a .= ",`".$col_s."`='".$row_post['sale_date']."'";
							}
							else
							{
							$a .= ",`".$col_s."`='".$val_s."'";
							}
						}
					}
				}
				$c++;
				
			mysql_query($a,$kdbc);
			
		}
		
		
		
		
		$qry_g_sale = "SELECT * FROM sales_table_item WHERE company_id='9' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_sale = mysql_query($qry_g_sale,$dbc);
		$sub_total = 0;
        $total = 0;
        $total_tax = 0;
        $s_t_6 = 0;
        $s_t_7 = 0;
		while($row_g_sale = mysql_fetch_array($res_g_sale))
		{
			
            $sub_total = number_format($sub_total + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']), 3, '.', '');
            // $total = number_format($total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty'])),3, '.', '');
			if($row_g_sale['qty']>0)
			{
             $total_tax = number_format(($total_tax + ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
			else
			{
				$total_tax = number_format(($total_tax - ($row_g_sale['tax'] * $row_g_sale['wholesale_price']) / 100), 3, '.', '');
			}
            $total = $total + (($row_g_sale['wholesale_price'] * $row_g_sale['qty']));
            ////////////////////////
            $product_id = $row_g_sale['product_no'];
            $query_5 = "SELECT * FROM  `product_table` WHERE product_no = '".$product_id."'";
            $result_5 = mysql_query($query_5,$dbc);
            $row_5 = mysql_fetch_array($result_5);
            $Adv_flag = $row_5['Adv_flag'];
            if ($Adv_flag == 6) 
			{
                $s_t_6 = $s_t_6 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
            } 
			else if ($Adv_flag == 7)
			 {
                $s_t_7 = $s_t_7 + ($row_g_sale['wholesale_price'] * $row_g_sale['qty']);
             }
		}
		$dis_sister = "SELECT `sister` FROM distributor_tbl WHERE company=9";
		$res_sister = mysql_query($dis_sister,$dbc);
		$row_sister = mysql_fetch_array($res_sister);
		
		
		$qry_loc = "SELECT * FROM `sister_account` WHERE store_id='" . $_SESSION['store_id'] . "' AND sister='N'";
		$res_loc = mysql_query($qry_loc,$dbc);
		$row_loc = mysql_fetch_array($res_loc);
		
		$qry_loc2 = "SELECT id FROM `test_inventory_table` WHERE old_location='" . $row_loc['location'] . "'";
		$res_loc2 = mysql_query($qry_loc2,$dbc);
		$row_loc2 = mysql_fetch_array($res_loc2);
		

        $qry_get_acc = "SELECT * FROM sister_account WHERE sister='" . $row_sister['sister'] . "' AND store_id='" . $_SESSION['store_id'] . "' AND location LIKE '%" . $row_loc['location'] . "%'";
        $res_get_acc = mysql_query($qry_get_acc,$dbc);
        $row_get_acc = mysql_fetch_array($res_get_acc);

        $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['sales_customer_account'] . "' || old_account='" . $row_get_acc['sales_customer_account'] . "'";
        $res_acc = mysql_query($qry_acc,$dbc);
        $row_7 = mysql_fetch_array($res_acc);

       /* $acc_no = $row_7['account_no_format'];
        $acc_id = $row_7['account_tree_id'];
        $acc_name = $row_7['account_eng'];*/
		
		$qry_pos_accnt = "SELECT s.`pos_cus_account`,a.`account_no_format`,a.`account_eng`,a.`account_tree_id` FROM `store_cons_account_tbl` as s JOIN `acoount_tree_table` as a ON `s`.`pos_cus_account`=`a`.`account_no_format` WHERE s.`store_id`='" . $_SESSION['store_id'] . "' AND s.`company_id`=9";
    $res_pos_accnt = mysql_query($qry_pos_accnt,$dbc);
    $row_pos_accnt = mysql_fetch_array($res_pos_accnt);

    $acc_no = mysql_real_escape_string($row_pos_accnt['account_no_format']);
    $acc_id = mysql_real_escape_string($row_pos_accnt['account_tree_id']);
    $acc_name = mysql_real_escape_string($row_pos_accnt['account_eng']);
		
		
		 $query_2 = "INSERT INTO `sales_table` SET `invoice_no`='" . $invoice_no . "',`store_id`='" . $_SESSION['store_id'] . "',`sale_date`='" . $row_post['sale_date'] . "',`currency`='JOD',`taxable`='Yes',`acc_no`='" . $acc_no . "',`acc_id`='" . $acc_id . "',`acc_name`='" . $acc_name . "',`location`='" . $row_loc2['id'] . "',`sale_person`='" . $row_8['store_manager'] . "',`sub_total`='" . $sub_total . "',`tax_total`='" . $total_tax . "',`grand_total`='" . ($sub_total + $total_tax) . "',`prepared_by`='".$_SESSION['Gen_ID']."',`prepared_date`='".$row_post['sale_date']."',`approve_by`='".$_SESSION['Gen_ID']."',`approve_date`='".$row_post['sale_date']."',`posted_by`='".$_SESSION['Gen_ID']."',`posted_date`='".$row_post['sale_date']."',`credit_limit`='',`credit_balance`='',`unpaid_cheques`='',`FOC_Goods`='',`FOC_Advertising`='',`Goods`='" . $s_t_6 . "',`Paid_Advertising`='" . $s_t_7 . "',`company_id`=9,`userid`='" . $row_8['customer_no'] . "',`consignment`='',`chain_id`='',`sale_date_time`='" . $row_post['sale_date'] . "',`type`='POS',`status`=0,`new_status`='1',all_update =0,from_c=8";
            mysql_query($query_2,$kdbc);
            $sales_id = mysql_insert_id($kdbc);
			
			$qry_g_insert = "SELECT * FROM sales_table_item WHERE company_id='9' AND all_update=1 AND store_id='".$_SESSION['store_id']."'";
		$res_g_insert = mysql_query($qry_g_insert,$dbc);
		while($row_4 = mysql_fetch_array($res_g_insert))
			{
				  $insert_sale_item = "INSERT INTO `sales_table_item` SET `sales_id`='" . $sales_id . "',`product_id`='" . $row_4['product_id'] . "',`product_no`='" . $row_4['product_no'] . "',`title`='" . $row_4['title'] . "',`category`='" . $row_4['category'] . "',`tax`='" . $row_4['tax'] . "',`discount`='" . $row_4['discount'] . "',`qty`='" . $row_4['qty'] . "',`rec_qty`='" . $row_4['qty'] . "',`adv`='" . $row_4['adv'] . "',`retail_price`='" . $row_4['retail_price'] . "',`wholesale_price`='" . $row_4['wholesale_price'] . "',`total`='" . $row_4['total'] . "',`sales_person`='" . $row_4['sales_person'] . "',`sales_person_id`='" . $row_4['sales_person_id'] . "',`store_id`='" . $row_4['store_id'] . "',`company_id`=9,`acc_no`='" . $row_4['acc_no'] . "',`acc_id`='" . $row_4['acc_id'] . "',`location`='" . $row_4['location'] . "',`brand`='" . $row_4['brand'] . "',`supplier`='" . $row_4['supplier'] . "',`post`=1,`brand_id`='" . $row_4['brand_id'] . "',`supplier_id`='" . $row_4['supplier_id'] . "',`brand_code`='" . $row_4['brand_code'] . "',`supp_code`='" . $row_4['supp_code'] . "',`posted_date`='" . $row_post['sale_date'] . "',`barcode`='" . $row_4['barcode'] . "',`ref_no`='" . $row_4['ref_no'] . "',`sub_store`='" . $row_4['sub_store'] . "',`chain_id`='" . $row_4['chain_id'] . "',`transaction_no`='" . $invoice_no . "',`type`='" . $row_4['type'] . "',`main_cat_id`='" . $row_4['main_cat_id'] . "',`division`='" . $row_4['division'] . "',`distributor`='" . $row_4['distributor'] . "',`payment_type`='" . $row_4['payment_type'] . "',`status`=0,`card_no`='" . $row_4['card_no'] . "',`card_type`='" . $row_4['card_type'] . "',`cat_id`='" . $row_4['cat_id'] . "',`sub_cat_id`='" . $row_4['sub_cat_id'] . "',`func_flag`='" . $row_4['func_flag'] . "',`sale_date_time`='" . $row_post['sale_date'] . "',`sale_date`='" . $row_post['sale_date'] . "',`discount_price`='" . $row_4['discount_price'] . "',`tax_price`='" . $row_4['tax_price'] . "',`from_company`='" . $row_4['from_company'] . "',`old_invoice`='" . $row_4['old_invoice'] . "',`unit_price_wot`='" . $row_4['unit_price_wot'] . "',`unit_price_wt`='" . $row_4['unit_price_wt'] . "',`Custmr_Dscnt`='" . $row_4['Custmr_Dscnt'] . "',`Custmr_Dscnt_Value`='" . $row_4['Custmr_Dscnt_Value'] . "',`Invest`='" . $row_4['Invest'] . "',`Invest_Disc_Value_WT`='" . $row_4['Invest_Disc_Value_WT'] . "',`Extra_Dscn_per`='" . $row_4['Extra_Dscn_per'] . "',`Extra_Dscnt_Value_WT`='" . $row_4['Extra_Dscnt_Value_WT'] . "',`Notes`='" . $row_4['Notes'] . "',`posting_date`='" . $row_4['posting_date'] . "',`store_manager`='" . $row_4['store_manager'] . "',`customer_name`='" . $row_4['customer_name'] . "',`customer_no`='" . $row_4['customer_no'] . "',`new_status`='" . $row_4['new_status'] . "',phone='" . $row_4['phone'] . "',rand_pur='" . $row_4['rand_pur'] . "',tax_free='" . $tax_frrr . "',all_update =0,sub_invoice='".$row_4['transaction_no']."'";
				
				 mysql_query($insert_sale_item,$kdbc);
			}
			
			
			
			
        $qry_get_acc = "SELECT * FROM store_cons_account_tbl WHERE   store_id='" . $_SESSION['store_id'] . "' AND company_id=9";
        $res_get_acc = mysql_query($qry_get_acc,$dbc);
        $row_get_acc = mysql_fetch_array($res_get_acc);

        $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_sale_account'] . "' || old_account='" . $row_get_acc['pos_sale_account'] . "'";

        $res_acc = mysql_query($qry_acc,$dbc);
        $row_7 = mysql_fetch_array($res_acc);

        $pos_sale_account = $row_7['account_no_format'];
        //$acc_id = $row_7['account_tree_id'];
        $pos_sale_account_name = $row_7['account_eng'];

        ///////////
        if ($row_get_acc['invesment_acc'] != '') {
            $qry_acc = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['invesment_acc'] . "' || old_account='" . $row_get_acc['invesment_acc'] . "'";

            $res_acc = mysql_query($qry_acc,$dbc);
            $row_7 = mysql_fetch_array($res_acc);

            $invesment_acc = $row_7['account_no_format'];
            //$acc_id = $row_7['account_tree_id'];
            $invesment_acc_name = $row_7['account_eng'];
        }
        $qry_acc1 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_tax_account'] . "' || old_account='" . $row_get_acc['pos_tax_account'] . "'";
        $res_acc1 = mysql_query($qry_acc1,$dbc);
        $row_8 = mysql_fetch_array($res_acc1);
        $pos_tax_account = $row_8['account_no_format'];
        $pos_tax_account_name = $row_8['account_eng'];
        $qry_acc2 = "SELECT * FROM acoount_tree_table WHERE account_no_format='" . $row_get_acc['pos_cus_account'] . "' || old_account='" . $row_get_acc['pos_cus_account'] . "'";
        $res_acc2 = mysql_query($qry_acc2,$dbc);
        $row_8 = mysql_fetch_array($res_acc2);
        $pos_cus_account = $row_8['account_no_format'];
        $pos_cus_account_name = $row_8['account_eng'];
		$qry_cur = "SELECT * FROM currency_table WHERE currency='JOD'";
		$res_cur = mysql_query($qry_cur,$dbc);
		$row_cur = mysql_fetch_array($res_cur);
		$decimal_value = $row_cur['decimal_value'];
		$sale_account_debit = number_format($sub_total, $decimal_value, '.', '');
		$consignment_tax_Account_debit = number_format($total_tax, $decimal_value, '.', '');
		$Supp_Account_credit = number_format($sub_total + $total_tax, $decimal_value, '.', '');

		$qry_sttt11 = "SELECT * FROM store_table WHERE store_id='" . $_SESSION['store_id'] . "'";
		$res_stt11 = mysql_query($qry_sttt11,$dbc);
		$row_stt11 = mysql_fetch_array($res_stt11);
		$inv_account_credit = $sub_total * $row_stt11['invs_per'] / 100;

		$qry_rate = "SELECT * FROM comapny_currency_table WHERE currency_id='" . $row_cur['id'] . "'";
		$res_rate = mysql_query($qry_rate,$dbc);
		$row_rate = mysql_fetch_array($res_rate);
         
		  

		$currency_rate = 1;
		$sale_account_base_debit = number_format(($sub_total * $currency_rate), $decimal_value, '.', '');
		$consignment_tax_Account_base_debit = number_format(($total_tax * $currency_rate), $decimal_value, '.', '');
		$total = $sale_account_base_debit + $consignment_tax_Account_base_debit;
		$Supp_Account_base_credit = number_format(($total * $currency_rate), $decimal_value, '.', '');
		
		
		$qry_tran = "INSERT INTO account_transaction_table SET trans_type='Sale',trans_no='" . $invoice_no . "',trans_date='" . $row_post['sale_date'] . "',company=9,account_no='" . $pos_sale_account . "',store_id='" . $_SESSION['store_id'] . "',location='" . $row_loc2['id'] . "',`pos_type`='pos'";
    mysql_query($qry_tran,$kdbc);
    $id = mysql_insert_id($kdbc);

    $qry_tran_acc = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_sale_account . "',account_name='" . $pos_sale_account_name . "',short_desc='" . $invoice_no . "',debit='" . $sale_account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_debit='" . $Supp_Account_credit . "',trans_date='" . $row_post['sale_date'] . "',company=9,location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos'',debit1='" . $sale_account_debit . "',base_debit1='" . $Supp_Account_credit . "'";
    mysql_query($qry_tran_acc,$kdbc);

    $qry_tran_acc1 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_tax_account . "',account_name='" . $pos_tax_account_name . "',short_desc='" . $invoice_no . "',credit='" . $consignment_tax_Account_debit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $consignment_tax_Account_base_debit . "',trans_date='" . $row_post['sale_date'] . "',company=9,location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos',credit1='" . $consignment_tax_Account_debit . "',base_credit1='" . $consignment_tax_Account_base_debit . "'";
    mysql_query($qry_tran_acc1,$kdbc);


    $qry_tran_acc2 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $pos_cus_account . "',account_name='" . $pos_cus_account_name . "',short_desc='" . $invoice_no . "',credit='" . $total . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $Supp_Account_base_credit . "',trans_date='" . $row_post['sale_date'] . "',company=9,location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale',`pos_type`='pos',credit1='" . $total . "',base_credit1='" . $Supp_Account_base_credit . "'";
    mysql_query($qry_tran_acc2,$kdbc);
   /* if ($row_get_acc['invesment_acc'] != '') {
        $qry_tran_acc3 = "INSERT INTO transaction_account_table SET acc_trans_id='" . $id . "',account_no='" . $invesment_acc . "',account_name='" . $invesment_acc_name . "',short_desc='" . $invoice_no . "',credit='" . $inv_account_credit . "',currency='" . $currency . "',currency_rate='" . $currency_rate . "',base_credit='" . $inv_account_credit . "',trans_date='" . $row_post['sale_date'] . "',company=9,location='" . $row_loc2['id'] . "',store_id='" . $_SESSION['store_id'] . "',trans_type='Sale'";
        mysql_query($qry_tran_acc3,$kdbc);
    }*/
	
	
	/////////////////////////////////////////////////// TARF Sale /////////////////////////////////////////////////////////////////////////////////
	
	
$qry_up1 = "UPDATE sales_table_item SET all_update =0,posted_date='".$row_post['sale_date']."' WHERE  all_update =1  AND  store_id='".$_SESSION['store_id']."'";
				mysql_query($qry_up1,$dbc);
				
				
				$qry_up1 = "UPDATE purchase_table_item SET all_update =0,posted_date='".$row_post['sale_date']."' WHERE  all_update =1  AND  store_id='".$_SESSION['store_id']."'";
				mysql_query($qry_up1,$dbc);
				
				
				$qry_up2 = "UPDATE account_product_table SET all_update =0,posted_date='".$row_post['sale_date']."' WHERE all_update =1 AND store_id='".$_SESSION['store_id']."'";
				mysql_query($qry_up2,$dbc);
				
				
	
	
	$qry_p1 = "SELECT * FROM payment_table WHERE all_update =1";
	$res_p1 = mysql_query($qry_p1,$dbc);
	while($row_p1 = mysql_fetch_array($res_p1))
	{
		$qry_p2 = "INSERT INTO  `payment_table` SET `paymnt_invoice`='".$row_p1['paymnt_invoice']."',`paymnt_type`='".$row_p1['paymnt_type']."',`paymnt_amount`='".$row_p1['paymnt_amount']."',`paymnt_card`='".$row_p1['paymnt_card']."',`paymnt_name`='".$row_p1['paymnt_name']."',`paymnt_date`='".$row_p1['paymnt_date']."',`company_id`='".$row_p1['company_id']."',`store_id`='".$row_p1['store_id']."',`paymnt_date_char`='".$row_p1['paymnt_date_char']."',`refund_amnt`='".$row_p1['refund_amnt']."',posted_date='".$row_post['sale_date']."',all_update =0";
		mysql_query($qry_p2,$sdbc);
	}
	
	$qry_o1 = "SELECT * FROM open_drawer WHERE all_update =1";
	$res_o1 = mysql_query($qry_o1,$dbc);
	while($row_o1 = mysql_fetch_array($res_o1))
	{
		$qry_o2 = "INSERT INTO  `open_drawer` SET `user_id`='".$row_o1['user_id']."',`store_id`='".$row_o1['store_id']."',`company_id`='".$row_o1['company_id']."',`open_time`='".$row_o1['open_time']."',posted_date='".$row_post['sale_date']."',all_update =0";
		mysql_query($qry_o2,$sdbc);
	}
	
	$qry_v1 = "SELECT * FROM void_pos_table WHERE all_update =1";
	$res_v1 = mysql_query($qry_v1,$dbc);
	while($row_v1 = mysql_fetch_array($res_v1))
	{
		$qry_v2 = "INSERT INTO  `void_pos_table` SET `product_id`='".$row_v1['product_id']."',`product_qty`='".$row_v1['product_qty']."',`void_amount`='".$row_v1['void_amount']."',`void_operator`='".$row_v1['void_operator']."',`void_salesman`='".$row_v1['void_salesman']."',`store_id`='".$row_v1['store_id']."',`company_id`='".$row_v1['company_id']."',`void_date`='".$row_v1['void_date']."',`void_time`='".$row_v1['void_time'].",`void_operator`='".$row_v1['void_operator']."',`void_operator`='".$row_v1['void_operator']."',posted_date='".$row_post['sale_date']."',all_update =0";
		mysql_query($qry_v2,$sdbc);
	}
				
				
				$qry_up4 = "UPDATE payment_table SET all_update =0,posted_date='".$row_post['sale_date']."' WHERE all_update =1 AND  store_id='".$_SESSION['store_id']."'";
				mysql_query($qry_up4,$dbc);
				
				
				$qry_up4 = "UPDATE open_drawer SET all_update =1,posted_date='".$row_post['sale_date']."' WHERE all_update =0 AND  store_id='".$_SESSION['store_id']."'";
				mysql_query($qry_up4,$dbc);
				
				$qry_up4 = "UPDATE 	void_pos_table SET all_update =1,posted_date='".$row_post['sale_date']."' WHERE all_update =0 AND  store_id='".$_SESSION['store_id']."'";
				mysql_query($qry_up4,$dbc);
				
				$qry_up4 = "UPDATE 	posted_table  SET sl_no ='".$sl_no."' WHERE id=1";
				mysql_query($qry_up4,$dbc);
	
	
		
		$qry_logout = "UPDATE saleman_log SET log_out='".date('Y-m-d H:i:s')."',new_status=1,posted_date='".$row_post['sale_date']."' WHERE log_out='0000-00-00 00:00:00' AND store_id='".$_SESSION['store_id']."'";
		 mysql_query($qry_logout,$dbc);
		 
		 $qry_logout = "UPDATE saleman_log SET log_out='".date('Y-m-d H:i:s')."',new_status=1,posted_date='".$row_post['sale_date']."' WHERE log_out='0000-00-00 00:00:00' AND store_id='".$_SESSION['store_id']."'";
		 mysql_query($qry_logout,$sdbc);
		 
		 
		 $qry_logout = "UPDATE saleman_log SET posted_date='".$row_post['sale_date']."',all_update =1 WHERE all_update=0 AND store_id='".$_SESSION['store_id']."'";
		 mysql_query($qry_logout,$dbc);
		 
		 
		  $qry_logout = "UPDATE saleman_log SET posted_date='".$row_post['sale_date']."',all_update =1 WHERE all_update=0 AND store_id='".$_SESSION['store_id']."'";
		 mysql_query($qry_logout,$sdbc);
		
		
session_unset();
session_destroy();
echo '<script type="text/javascript">window.location="http://localhost/pos/"</script>';

			}
			else
			{
				echo '<script type="text/javascript">window.location="http://localhost/pos/dashboard.php"</script>';
			}

?>
      <div class="col-lg-12">
      
        <div class="reportDiv">
          
          <p style="height:100px;"></p>
           
          <table class="table table-bordered table2excel" data-tableName="Test Table 1">
            <tbody>
         <tr><td colspan="12" align="center" style="color:#090;font-size:34px"><em>Transaction Created and sales logout Successfully</em></td></tr>
		 <tr><td colspan="12" align="center" style="color:#090;font-size:24px"><em>
		
		 </em></td></tr>
            </tbody>
          </table>
		  <?php
			
			session_destroy();
		?>
        </div>
      </div>
    </div>
    <!--/.row--> 
  </div>
  <!--/.container--> 
</section>
<!--/#content--> 

<script src="js/bootstrap.min.js"></script> 
<script src="dist/js/classie.js"></script> 
<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				
				body = document.body;

			showLeft.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeft' );
			};
			

			function disableOther( button ) {
				if( button !== 'showLeft' ) {
					classie.toggle( showLeft, 'disabled' );
				}
				
			}
		</script> 

<!-- Include Date Range Picker --> 

</body>
</html>