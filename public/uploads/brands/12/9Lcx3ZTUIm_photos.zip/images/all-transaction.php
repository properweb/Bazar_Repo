<?php include "new-header.php"; ?>
<div class="col-lg-12 col-md-12">
    <?php 
      $qry_pay1 = "SELECT * FROM sales_table_item WHERE sale_date ='".date('Y-m-d')."' AND status=2 AND `type`='pos' AND store_id='".$_SESSION['store_id']."'  ORDER BY sale_date_time ASC";
      $res_pay1 = mysql_query($qry_pay1);
      $numrows1 = mysql_num_rows($res_pay1);
      if($numrows1 > 0)
      {
      ?>
     <!-- <a href="create-transaction.php"  style="float:right;">
      <button class="btn btn-primary" type="button">Create Transaction & Logout</button>
      </a><-->
      <?php
      }
      ?>
    <div class="reportDiv">
        <h3>Today Sales</h3>
        <p>
            <label>Date:</label>
            <span><?php echo date('m/d/Y'); ?></span></p>
        <p>
            <label>Day:</label>
            <span><?php echo date('D') ?></span></p>
        <h4>P.O.SALE NAME : <span><?php echo stripslashes($row_get_store['store_name']) ?> </span></h4>
        <table class="table table-bordered table2excel" data-tableName="Test Table 1" style="font-size:12px;">
            <thead>
                <tr>
                    <th>Time</th>
                    <th>Item No</th>
                    <th>Description</th>
                    <th>Dept. </th>
                    <th>Amount</th>
                    <th>Discount</th>
                    <th>Tax Free</th>
                    <th>Net Amount</th>

                    <th>Qty</th>
                    <th>Brand</th>
                    <th>Supplier</th>
                    <th>Invoice NO</th>
                    <th>Sales Person</th>
                    <th>Customer Account</th>
                    <th>Customer Name</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $qry_invoice = "SELECT distinct(transaction_no) FROM sales_table_item WHERE sale_date ='" . date('Y-m-d') . "' AND status=2 AND `type`='pos' AND store_id='" . $_SESSION['store_id'] . "' AND company_id='".$_SESSION['company_id']."' ORDER BY id ASC";
                $res_invoice = mysql_query($qry_invoice);
                $num_invoice = mysql_num_rows($res_invoice);
                if ($num_invoice > 0) {
                    while ($row_invoice = mysql_fetch_array($res_invoice)) {
                        $qry_pay = "SELECT * FROM sales_table_item WHERE `transaction_no` ='" . $row_invoice['transaction_no'] . "' ORDER BY id ASC";
                        $res_pay = mysql_query($qry_pay);
                        $invoice_net_total = 0;
						$sale = 0;
                        while ($row_pay = mysql_fetch_array($res_pay)) {
                            $net_sale = 0;
                            $qry_cus = "SELECT cus_name FROM sales_table WHERE sales_id='" . $row_pay['sales_id'] . "'";
                            $res_cus = mysql_query($qry_cus);
                            $row_cus = mysql_fetch_array($res_cus);
                            $explode = explode(' ', $row_pay['sale_date_time']);
                            $explode = explode(':', $explode[1]);

                            $qry5 = "SELECT customer_id FROM pos_customer WHERE customer_name='" . $row_pay['customer_name'] . "'";
                            $res5 = mysql_query($qry5);
                            $row5 = mysql_fetch_array($res5);
							if ($row_pay['qty'] < 0) {
                                $row_pay['qty'] = 1;
                            } else {
                                $row_pay['qty'] = $row_pay['qty'];
                            }
							$sale = $row_pay['retail_price'] * $row_pay['qty'];
							if($sale<0){
								$net_sale = $sale + $row_pay['discount_price'];
							}else{
								$net_sale = $sale - $row_pay['discount_price'];
							}
                            $invoice_net_total += $net_sale;
							
							if($row_pay['tax_free']==1)
							{
								$tax_free = 'Yes';
							}
							else
							{
								$tax_free = 'No';
							}
                            ?>
                            <tr>
                                <td><?php echo $explode[0] . ':' . $explode[1]; ?></td>
                                <td><?php echo $row_pay['product_no'] ?></td>
                                <td><?php echo $row_pay['title'] ?></td>
                                <td style="font-size:10px;"><?php echo $row_pay['category'] ?></td>
                                <td><?php echo $row_pay['retail_price']; ?></td>
                                <td><?php echo $row_pay['discount_price'] ?></td>
                                <td><?php echo $tax_free;?></td>
                                <td><?php echo $net_sale; ?></td>
                                <td><?php echo $row_pay['qty'] ?></td>
                                <td><?php echo $row_pay['brand'] ?></td>
                                <td><?php echo $row_pay['supplier'] ?></td>
                                <td><?php echo $row_pay['transaction_no'] ?></td>
                                <td><?php echo $row_pay['sales_person'] ?></td>
                                <td><?php echo $row5['customer_id'] ?></td>
                                <td><?php echo $row_pay['customer_name'] ?></td>
                            </tr>
                            <?php
                        }
                        ?>
                            <tr style="border-bottom: 4px solid #0085be;">
                            <td colspan="13">&nbsp;</td>
                            <td><strong>Total</strong></td>
                            <td><strong><?php echo $invoice_net_total; ?></strong></td>
                        </tr>
                        <?php
                    }
                } else {
                    ?>
                    <tr><td colspan="13" align="center" style="color:#F00;font-size:16px"><em>No Record Found</em></td></tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
</div>
<!--/.row--> 
</div>
<!--/.container--> 
</section>
<!--/#content--> 

<script src="js/bootstrap.min.js"></script> 
<script src="dist/js/classie.js"></script> 
<script>
    var menuLeft = document.getElementById('cbp-spmenu-s1'),
            body = document.body;

    showLeft.onclick = function () {
        classie.toggle(this, 'active');
        classie.toggle(menuLeft, 'cbp-spmenu-open');
        disableOther('showLeft');
    };


    function disableOther(button) {
        if (button !== 'showLeft') {
            classie.toggle(showLeft, 'disabled');
        }

    }
</script> 

<!-- Include Date Range Picker --> 

<script>

    function expot() {
        $(function () {
            $(".table2excel").table2excel({
                exclude: ".noExl",
                name: "Excel Document Name",
                filename: "<?php echo "Group-Sale-Report" . date("Y-m-d") ?>",
                fileext: ".xls",
                exclude_img: true,
                exclude_links: true,
                exclude_inputs: true
            });
        });
    }
</script>
</body>
</html>