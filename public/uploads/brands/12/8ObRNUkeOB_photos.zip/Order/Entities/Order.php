<?php

namespace Modules\Order\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Order extends Model
{
    //Declare statuses
    const ORDER_STATUS = 'new';

    //Declare payment statuses
    const PAYMENT_STATUS_UNPAID = 'Unpaid';

    //Declare payment methods
    const PAYMENT_METHOD_COD = 'cod';

    const DEFAULT_IMAGE_PATH = 'public/admin/dist/img/logo-image.png';

    protected $fillable = [
        'brand_id',
        'user_id',
        'order_number',
        'sub_total',
        'quantity',
        'delivery_charge',
        'status',
        'total_amount',
        'name',
        'country',
        'post_code',
        'address1',
        'address2',
        'phone',
        'email',
        'payment_method',
        'payment_status',
        'shipping_id',
        'coupon',
        'state',
        'town',
        'shipping_date'
    ];

}
