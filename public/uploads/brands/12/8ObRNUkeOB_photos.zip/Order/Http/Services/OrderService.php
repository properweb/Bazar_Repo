<?php

namespace Modules\Order\Http\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Modules\Brand\Entities\Brand;
use Modules\Cart\Entities\Cart;
use Modules\order\Entities\Order;
use Modules\Product\Entities\Products;
use Modules\User\Entities\User;

class OrderService
{
    protected User $user;

    protected Order $order;

    protected Brand $brand;

    /**
     * Save order
     *
     * @param array $request
     * @return array
     */
    public function store(array $requestData): array
    {
        $cart = Cart::where('user_id', $requestData['user_id'])
            ->where('order_id', null)
            ->first();

        // return error if cart is empty
        if (empty($cart)) {
            return [
                'res' => false,
                'msg' => 'Cart is Empty !',
                'data' => ""
            ];
        }

        DB::beginTransaction();

        try {
            $this->user = User::findOrFail($requestData['user_id']);

            $this->brand = Brand::where('brand_key', $requestData['brand_key'])->first();

            $this->order = $this->createOrder($requestData);

            //set order_id for cart
            Cart::where('user_id', $this->user->id)->where('order_id', null)->update(['order_id' => $this->order->id]);

            $this->syncProducts();

            $cartDet = $this->getCartDet();

            //fixme refactor
            if ($this->order->country) {
                $country = DB::table('countries')->where('id', $this->order->country)->first();
                $this->order->country = $country->name;
            }

            if ($this->order->state) {
                $state = DB::table('states')->where('id', $this->order->state)->first();
                $this->order->state = $state->name;
            }

            if ($this->order->town) {
                $town = DB::table('cities')->where('id', $this->order->town)->first();
                $this->order->town = $town->name;
            }

            $response = [
                'res' => true,
                'msg' => 'Your product successfully placed in order',
                'data' => [
                    'order_det' => $this->order,
                    'cart_det' => $cartDet
                ]
            ];

            DB::commit();
            //todo Log successfull creation
        } catch (\Exception $e) {
            // something went wrong
            //todo Log exception
            DB::rollback();
            $response = [
                'res' => false,
                'msg' => 'Cart is Empty !',
                'data' => ""
            ];

        }

        return $response;
    }

    /**
     * Create new order
     *
     * @param  array  $orderData
     * @return Order
     */
    public function createOrder(array $orderData): Order
    {
        //set order data
        $orderData['order_number'] = 'ORD-' . strtoupper(Str::random(10));

        $orderData['user_id'] = $this->user->id;
        $orderData['user_email'] = $this->user->email;

        $orderData['brand_id'] = $this->brand->user_id;
        $orderData['shipping_date'] = date('Y-m-d', strtotime("+" . $this->brand->avg_lead_time . " days"));

        $orderData['sub_total'] = Cart::where('user_id', $this->user->user_id)->where('order_id', null)->sum('amount');
        $orderData['quantity'] = Cart::where('user_id', $this->user->user_id)->where('order_id', null)->sum('quantity');
        $orderData['total_amount'] = Cart::where('user_id', $this->user->user_id)->where('order_id', null)->sum('amount');

        $orderData['status'] = Order::ORDER_STATUS;
        $orderData['payment_method'] = Order::PAYMENT_METHOD_COD;
        $orderData['payment_status'] = Order::PAYMENT_STATUS_UNPAID;

        //create order
        $order = new Order();
        $order->fill($orderData);
        $order->save();

        return $order;
    }

    /**
     * Get Cart det
     *
     * @return array
     */
    public function getCartDet(): array
    {
        $brands = Cart::where('user_id', $this->user->id)
            ->where('order_id', $this->order->id)
            ->groupBy('brand_id')
            ->get();

        $carts = [];

        foreach ($brands as $brandKey => $brandValue) {
            $brand = Brand::where('user_id', $brandValue['brand_id'])->first();
            $carts[$brandKey]['brand_id'] = $brand->user_id;
            $carts[$brandKey]['brand_name'] = $brand->brand_name;
            $carts[$brandKey]['brand_logo'] = $brand->logo_image != '' ? asset('public') . '/' . $brand->logo_image : asset('public/img/logo-image.png');

            $cartProducts = Cart::where('user_id', $this->user->id)
                ->where('order_id', $this->order->id)
                ->where('brand_id', $brandValue['brand_id'])
                ->get();

            foreach ($cartProducts as $productKey => $productValue) {
                $product = Products::where('id', $productValue['product_id'])->first();
                $carts[$brandKey]['products'][$productKey]['id'] = $productValue['id'];
                $carts[$brandKey]['products'][$productKey]['product_id'] = $product->id;
                $carts[$brandKey]['products'][$productKey]['product_name'] = $product->name;
                $carts[$brandKey]['products'][$productKey]['product_price'] = (float) $productValue['price'];
                $carts[$brandKey]['products'][$productKey]['product_qty'] = (int) $productValue['quantity'];
                $carts[$brandKey]['products'][$productKey]['product_image'] = $product->featured_image ?? asset(Order::DEFAULT_IMAGE_PATH);
            }
        }

        return $carts;
    }

    /**
     * Sync products
     */
    public function syncProducts(): void
    {
        $products = Cart::where('user_id', $this->user->id)
            ->where('order_id', $this->order->id)
            ->where('brand_id', $this->brand->user_id)
            ->get();

        $this->syncExternal($products, $this->brand->user_id);
    }

    /**
     * Sync products
     */
    public function syncExternal(array $products, int $brandId): void
    {
        //sync
    }
}
