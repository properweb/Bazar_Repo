<?php

namespace Modules\Order\Http\Controllers;

use Illuminate\Routing\Controller;
use Modules\Order\Http\Requests\StoreOrderRequest;
use Modules\Order\Http\Services\OrderService;


class OrderController extends Controller
{
    public function __construct(protected OrderService $orderService){}

    /**
     * Save order
     *
     * @param StoreOrderRequest $request
     * @return mixed
     */
    public function store(StoreOrderRequest $request)
    {
        $response = $this->orderService->store($request->all());

//        $this->orderService->store($request->validated());
        return response()->json($response);
    }
}
