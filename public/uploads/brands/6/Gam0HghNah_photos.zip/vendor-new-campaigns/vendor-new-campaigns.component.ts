import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import grapesjs from 'grapesjs';
import 'grapesjs-preset-newsletter';
import { orderBy } from 'lodash';
declare var $: any;
// import CKEDITOR from 'grapesjs-plugin-ckeditor'

@Component({
  selector: 'app-vendor-new-campaigns',
  templateUrl: './vendor-new-campaigns.component.html',
  styleUrls: ['./vendor-new-campaigns.component.css']
})
export class VendorNewCampaignsComponent implements OnInit {
  name = 'Angular 6';
  vareEditor!: any;

  recipantsTypeArray = [
    {id:1, name:'All Customers'},
    {id:2, name:'Ordered'},
    {id:3, name:'Contacted'},
    {id:4, name:'Unused credit'},
    {id:5, name:'Not yet ordered'},
    {id:6, name:'Uncontacted'},
    {id:7, name:'Not signed up'},
    {id:8, name:'On Faire'},
    {id:9, name:'Manual'},
  ]  

  constructor(public modalService: NgbModal) { }
  

  ngOnInit() {
   
    // const editor = grapesjs.init({
    //   container: '#gjs',
    //   // fromElement: 1,
    //   height: '100%',
    //   storageManager: false,
    //   plugins: ['gjs-preset-newsletter'],
    //   pluginsOpts: {
    //     'gjs-preset-newsletter': {
    //             modalTitleImport: 'Import template'
    //             // ... other options
    //           },
    //     'gjs-plugin-ckeditor': {
    //     position: 'left',
    //       options: {
    //        language: "en",
    //             //extraPlugins: "sourcedialog,justify,showblocks,colorbutton",
    //             removeButtons: "",
    //            // format_tags: "p;h1;h2;h3;h4;h5;h6;pre",
    //         //language: 'en',
    //         //startupFocus: true,
    //         //extraAllowedContent: '*(*);*{*}', // Allows any class and any inline style
    //         //allowedContent: true, // Disable auto-formatting, class removing, etc.
    //         //enterMode: CKEDITOR.ENTER_BR,
    //         /* uiColor: '#0000001a', // Inline editor color
    //         extraPlugins: 'basicstyles,justify',
    //         // extraPlugins: 'dialogui,dialog,a11yhelp,dialogadvtab,basicstyles,bidi,blockquote,notification,button,toolbar,clipboard,panelbutton,panel,floatpanel,colorbutton,colordialog,templates,menu,contextmenu,copyformatting,div,resize,elementspath,enterkey,entities,exportpdf,popup,filetools,filebrowser,find,fakeobjects,flash,floatingspace,listblock,richcombo,font,forms,format,horizontalrule,htmlwriter,iframe,wysiwygarea,image,indent,indentblock,indentlist,smiley,justify,menubutton,language,link,list,liststyle,magicline,maximize,newpage,pagebreak,pastetext,pastetools,pastefromgdocs,pastefromword,preview,print,removeformat,save,selectall,showblocks,showborders,sourcearea,specialchar,scayt,stylescombo,tab,table,tabletools,tableselection,undo,lineutils,widgetselection,widget,notificationaggregator,uploadwidget,uploadimage,wsc',
    //         toolbar:[
    //         [ "Format", "-", "Bold", "Italic", "Strike", "Underline", "Subscript", "Superscript", "RemoveFormat", "-", "NumberedList", "BulletedList", "-", "Outdent", "Indent", "-", "JustifyLeft", "JustifyCenter", "JustifyRight", "JustifyBlock", "-", "Link", "Unlink", "Anchor", "TextColor", "BGColor", "-", "ShowBlocks", "-", "Image", "Table", "-", "Sourcedialog"]
    //             ] */
    //             toolbar:[
    //         [ "Format", "Bold", "Italic", "Strike", "Underline", "NumberedList", "BulletedList", "JustifyLeft", "JustifyCenter", "JustifyRight", "JustifyBlock", "Style", "Link"]
    //             ]
    //       }
    //     }
    //   }
    // });
    
    let editor = grapesjs.init({
      // email-builder
      container: '#gjs-new',
      // canvas: {
      //   scripts: [
      //       "https://cdn.ckeditor.com/ckeditor5/12.4.0/classic/ckeditor.js"
      //   ]
      //   },
      plugins: ['gjs-preset-newsletter', 'gjs-plugin-ckeditor'],
      pluginsOpts: {
        'gjs-preset-newsletter': {
          modalTitleImport: 'Import template'
          // ... other options
        },
        'gjs-plugin-ckeditor' : {
          options: {
                  language: 'en',
                  position: 'top',
                  toolbarGroups: [
                    { name: 'document', groups: [ 'mode', 'document', 'doctools' ] },
                    { name: 'clipboard', groups: [ 'clipboard', 'undo' ] },
                    { name: 'editing', groups: [ 'find', 'selection', 'spellchecker', 'editing' ] },
                    { name: 'forms', groups: [ 'forms' ] },
                    '/',
                    { name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
                    { name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi', 'paragraph' ] },
                    { name: 'links', groups: [ 'links' ] },
                    { name: 'insert', groups: [ 'insert' ] },
                    '/',
                    { name: 'styles', groups: [ 'styles' ] },
                    { name: 'colors', groups: [ 'colors' ] },
                    { name: 'tools', groups: [ 'tools' ] },
                    { name: 'others', groups: [ 'others' ] },
                    { name: 'about', groups: [ 'about' ] }
                  ],
                  removeButtons: 'NewPage'
                },
        }
      
      },
      panels: false,
      storageManager: false
    });

    // editor.setCustomRte({
    //   /**
    //    * Enabling the custom RTE
    //    * @param  {HTMLElement} el This is the HTML node which was selected to be edited
    //    * @param  {Object} rte It's the instance you'd return from the first call of enable().
    //    *                      At the first call it'd be undefined. This is useful when you need
    //    *                      to check if the RTE is already enabled on the component
    //    * @return {Object} The return should be the RTE initialized instance
    //    */
    //   enable: function(el: any, rte: any) {
    //     // If already exists just focus
    //     if (rte) {
    //       this.focus(el, rte); // implemented later
    //       return rte;
    //     }
    
    //     // CKEditor initialization
    //     rte = CKEDITOR.inline(el, {
    //       // Your configurations...
    //       toolbar: [...],
    //       // IMPORTANT
    //       // Generally, inline editors are attached exactly at the same position of
    //       // the selected element but in this case it'd work until you start to scroll
    //       // the canvas. For this reason you have to move the RTE's toolbar inside the
    //       // one from GrapesJS. For this purpose we used a plugin which simplify
    //       // this process and move all next CKEditor's toolbars inside our indicated
    //       // element
    //       sharedSpaces: {
    //         top: editor.RichTextEditor.getToolbarEl(),
    //       }
    //     });
    
    //     this.focus(el, rte); // implemented later
    //     return rte;
    //   },
    // });

    editor.setComponents('<body><img src="assets/images/email-builder-logo.svg" alt="img" id="il5d"/><div class="spacing-class"> </div><div class="spacing-class"> </div><h2 id="ik56">[Make an Announcement]</h2><p id="ix5f">We&#039;re thrilled to share our new products with you - and Net 60 payment terms!</p><img src="assets/images/local-brands-image-min.png" alt="img" id="ik1hz"/><div class="spacing-class"> </div><p id="iucal">[Tell your retailers about the new products that you added to your shop. Give them the backstory of your new line, any details on the products, and perhaps even recommend items that work well together]</p><p id="ig25j">We are now partnering with Bazar, the online wholesale marketplace, so that you can try our new products with Net 60 terms and free returns on your first order!</p><p id="im86g">Plus, we won&#039;t be charged commission on any of your orders since you&#039;re an existing stockist of ours.</p><p id="ij9wf">If you&#039;re new to Bazar, you will also receive $100* in credit and a year of free shipping on My Amarant covered by Bazar.</p><p id="i9lop">[Tell your retailers about the new products that you added to your shop. Give them the backstory of your new line, any details on the products, and perhaps even recommend items that work well together]</p><p id="i2zp6">We think you&#039;ll enjoy the experience so much that you&#039;ll want to shop with us on Bazar again!</p><div id="iv3kx"><a id="i7g31">Shop</a></div><p id="ivdb7">Thanks,<br/>Best Seller</p><p id="ixecj">*€300 off for all European retailers, £300 for U.K. retailers, $100 for U.S. and Canadian retailers. Credit is only available to retailers new to Faire.</p></body>')
    editor.setStyle('* { box-sizing: border-box; } body {margin: 0;}*{box-sizing:border-box;}body{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;}*{box-sizing:border-box;}body{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;}*{box-sizing:border-box;}body{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;}*{box-sizing:border-box;}body{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;}*{box-sizing:border-box;}body{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;}*{box-sizing:border-box;}body{margin-top:0px;margin-right:0px;margin-bottom:0px;margin-left:0px;}#il5d{height:auto;max-height:90px;max-width:90px;clear:both;margin:1em auto 0 auto;display:block;}#ik56{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:24px;font-weight:Bold;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#ix5f{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#ik1hz{max-width:100%;display:block;margin:0 auto 0 auto;}#iucal{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#ig25j{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#im86g{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#ij9wf{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#i9lop{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#i2zp6{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#iv3kx{margin:0 0 1em 0;padding:0;text-align:center;width:100%;}#i7g31{background:#393939;border:1px solid #393939;border-radius:3px;color:#fff;display:inline-block;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:41px;padding:0 100px 0 100px;text-align:center;}#ivdb7{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}#ixecj{color:#000;font-family:Arial, Helvetica, sans-serif;font-size:16px;font-weight:normal;line-height:21px;margin:0 0 1em 0;padding:0 0.9375em 0 0.9375em;}')
    this.vareEditor = editor;
    // email-builder
    const bm = editor.Blocks; 

    //Step 1
    const blockTempleteOne = bm.add('templeteOne', {
      // Your block properties...
      label: 'Big announcement',
      category: 'Step 1 - Select a template',
      // attributes: { class: 'gjs-fonts gjs-f-image gjs-block gjs-one-bg gjs-four-color-h'},
      media: "<img src='assets/images/email-builder-big-announcement-icon.svg' alt=''>",
      content: '<img src="assets/images/email-builder-logo.svg"alt="img"style="height: auto; max-height: 90px; max-width: 90px; clear: both; margin: 1em auto 0 auto; display: block;"/><div class="spacing-class">&nbsp;</div><div class="spacing-class">&nbsp;</div><h2 style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 24px; font-weight: Bold; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">[Make an Announcement]</h2><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">We&#039;re thrilled to share our new products with you - and Net 60 payment terms!</p><img src="assets/images/local-brands-image-min.png"alt="img" style="max-width: 100%; display: block; margin: 0 auto 0 auto;"/><div class="spacing-class">&nbsp;</div><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">[Tell your retailers about the new products that you added to your shop. Give them the backstory of your new line, any details on the products, and perhaps even recommend items that work well together]</p><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">We are now partnering with Bazar, the online wholesale marketplace, so that you can try our new products with Net 60 terms and free returns on your first order!</p><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">Plus, we won&#039;t be charged commission on any of your orders since you&#039;re an existing stockist of ours.</p><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">If you&#039;re new to Bazar, you will also receive $100* in credit and a year of free shipping on My Amarant covered by Bazar.</p><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">[Tell your retailers about the new products that you added to your shop. Give them the backstory of your new line, any details on the products, and perhaps even recommend items that work well together]</p><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">We think you&#039;ll enjoy the experience so much that you&#039;ll want to shop with us on Bazar again!</p><div style="margin:0 0 1em 0; padding: 0;text-align: center; width: 100%;"><a style="background: #393939; border: 1px solid #393939; border-radius: 3px; color: #fff; display: inline-block; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 41px; padding: 0 100px 0 100px; text-align: center;">Shop</a></div><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">Thanks,<br/>Best Seller</p><p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">*€300 off for all European retailers, £300 for U.K. retailers, $100 for U.S. and Canadian retailers. Credit is only available to retailers new to Faire.</p>',
      attributes: { class: 'templeteOne' }
    });

    //Step 2
    const block = bm.add('header', {
      // Your block properties...
      label: 'Header',
      category: 'Step 2 - Customize your email',
      // attributes: { class: 'gjs-fonts gjs-f-image gjs-block gjs-one-bg gjs-four-color-h'},
      media: "<img src='assets/images/email-builder-header-icon.svg' alt=''>",
      content: '<h2 style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 24px; font-weight: Bold; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">[Make an Announcement]</h2>',
      attributes: { class: 'header' }
    });

    const blockSpacing  = bm.add('spacing',{ 
      label: 'Spacing',
      category: 'Step 2 - Customize your email',
      media: "<img src='assets/images/email-builder-text-icon.svg' alt=''>",
      content: "<div class='spacing-class'>&nbsp;</div>",
      attributes: { id: 'test' }
     })

    //  const blockbutton  = bm.add('buttonId',{ 
    //   label: 'Button',
    //   media: "<img src='assets/images/email-builder-text-icon.svg' alt=''>",
    //   content: [
    //     `<div class="el">Element</div>
    //     <div class="el2">Element 2</div>
    //     <style>
    //       .el { color: blue }
    //       .el2 { color: violet }
    //     </style>`,
    //   ],
    //   attributes: {
    //     class: 'button',   
    //   },
    //  })

    const blockbutton  = bm.add('buttonId',{ 
    label: 'Button',
    category: 'Step 2 - Customize your email',
    media: "<img src='assets/images/email-builder-button.svg' alt=''>",
    content: '<div style="text-align: center; width: 100%;"><a style="background: #393939; border: 1px solid #393939; border-radius: 3px; color: #fff; display: inline-block; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 41px; padding: 0 100px 0 100px; text-align: center;">Shop</a></div>',
    attributes: {
      class: 'button',   
    },
    })

    const blockparagraph  = bm.add('paragraph',{ 
      label: 'Text',
      category: 'Step 2 - Customize your email',
      media: "<img src='assets/images/email-builder-text-icon.svg' alt=''>",
      content: '<p style="color: #000; font-family: Arial, Helvetica, sans-serif; font-size: 16px; font-weight: normal; line-height: 21px; margin:0 0 1em 0; padding: 0 0.9375em 0 0.9375em;">[Tell your retailers about the new products that you added to your shop. Give them the backstory of your new line, any details on the products, and perhaps even recommend items that work well together]</p>',
      attributes: {
        class: 'paragraph',   
      },
    })

    const blockLogo = bm.add('LOGO', {
      label: 'Logo',
      category: 'Step 2 - Customize your email',
      attributes:  {
        class: 'logoimg'
      },
      // attributes: { class: 'gjs-fonts gjs-f-image gjs-block gjs-one-bg gjs-four-color-h'},
      media: "<img src='assets/images/email-builder-logo-icon.svg' alt=''>",
      content: { 
        type: 'image' , 
        activeOnRender: true,
        style : {
        'height': 'auto',
        'max-height': '90px',
        'max-width': '90px',
        'clear': 'both',
        'margin': '1em auto 0 auto',
        'display': 'block',
        } 
      },
      select: true,
      activate: true,
    });

    const blocks = editor.BlockManager.getAll();
    console.log(blocks);
    // document.getElementById('some-id')
    editor.Blocks.get('divider').set({  
      category: 'Step 2 - Customize your email',
      media: "<img src='assets/images/email-builder-divider.svg' alt=''>",
      attributes: {
        class: 'divider'
      }
     })

     editor.Blocks.get('image').set({ 
      category: 'Step 2 - Customize your email',
      content: { 
        type: 'image' , 
        activeOnRender: true,
        style : {
        'max-width': '100%',
        'display': 'block',
        'margin': '0 auto 0 auto',
        } 
      },
     })

    //  editor.Blocks.get('button').set({ 
    //   //label: 'My block', 
    //   media: "<img src='assets/images/email-builder-button.svg' alt=''>",
    //   attributes: {
    //     class: 'button',
    //   },
    //   style: {
    // 		width: '130px',
    // 		height: '50px',
    // 	},
    //   droppable: false,
    //   resizable: true,
    //   editable: true,
    //   order: 1,
    //   title: 'Link',
    //  })

    //  editor.Blocks.get('text').set({ 
    //   label: 'Text',
    //   media: "<img src='assets/images/email-builder-text-icon.svg' alt=''>",
    //   attributes: {
    //     class: 'text'
    //   }
    //  })

     editor.Blocks.get('image').set({ 
      media: "<img src='assets/images/email-builder-image-icon.svg' alt=''>",
      attributes: {
        class: 'image'
      }
     })

    //  editor.Blocks.get('quote').set({ 
    //   media: "<img src='assets/images/error_icon.png' alt=''>",
    //  })

    //  editor.BlockManager.get('quote').set({
    //   attributes: {
    //     class: 'quote'
    //   }
    // });

     /*editor.DeviceManager.add({
      id: 'tablet2',
      name: 'Tablet 2',
      width: '800px', // This width will be applied on the canvas frame
      widthMedia: '810px', // This width that will be used for the CSS media
      height: '600px', // Height will be applied on the canvas frame
     });*/

    //const device = editor.DeviceManager.get('Tablet');
    //console.log(JSON.stringify(device));
    //editor.DeviceManager.remove();
    editor.BlockManager.getAll().remove('text');
    editor.BlockManager.getAll().remove('sect100');
    editor.BlockManager.getAll().remove('sect50');
    editor.BlockManager.getAll().remove('sect30');
    editor.BlockManager.getAll().remove('sect37');
    editor.BlockManager.getAll().remove('text-sect');
    editor.BlockManager.getAll().remove('quote');
    editor.BlockManager.getAll().remove('button');
    editor.BlockManager.getAll().remove('link');
    editor.BlockManager.getAll().remove('link-block');
    editor.BlockManager.getAll().remove('list-items');
    editor.BlockManager.getAll().remove('grid-items');
    // console.log( editor.Panels);
    // editor.Panels.removeButton("views", "open-layers");
    // editor.Panels.removeButton("views", "open-sm");
    // editor.Panels.removeButton("views", "open-layers");
    // editor.Panels.removeButton('options','cmdImport');
    // editor.Panels.removeButton('options','cmdClear');


    const rte = editor.RichTextEditor;
    console.log(rte.getAll());
    rte.add('leftalign', {
      icon: '<b>L</b>',
      attributes: {title: 'LeftAlign', class: 'leftAlign'},
      result: (rte: any) => rte.insertHTML(`<div style="text-align: left;">${rte.selection()}</div>`)
    });
    rte.add('centeralign', {
      icon: '<b>C</b>',
      attributes: {title: 'CenterAlign', class: 'centerAlign'},
      result: (rte: any) => rte.insertHTML(`<div style="text-align: center;">${rte.selection()}</div>`)
    });

    const isValidAnchor = (rte: any) => {
      // a utility function to help determine if the selected is a valid anchor node
      const anchor = rte.selection().anchorNode;
      const parentNode  = anchor && anchor.parentNode;
      const nextSibling = anchor && anchor.nextSibling;
      return (parentNode && parentNode.nodeName == 'A') || (nextSibling && nextSibling.nodeName == 'A')
    }

    // rte.add('linkurl', {
    //   icon: '<b>li</b>',
    //   attributes: {title: 'LinkUrl'},
    //   // Example on it's easy to wrap a selected content
    //   result: (rte: any) => rte.insertHTML(`<a href="">${rte.selection()}</a>`)
    // });

    rte.remove('strikethrough');
    rte.remove('wrap');
    rte.remove('link');

    editor.on('component:selected', function(model) {
      // if no toolbar detected, call init (i am using isEmpty from lodash) but you can just validate this without it
      // if (model.attributes.toolbar) {
          model.initToolbar();
      // }
    }); 

    editor.Panels.removeButton("views", "tablet");

    const categories: any = editor.BlockManager.getCategories();
    categories.each((category: any, key: any) => {
      if(key > 0) {
        category.set('open', false).on('change:open', (opened: any) => {
          opened.get('open') && categories.each((category: any) => {
                  category !== opened && category.set('open', false)
              })
          })
      }
    })

  

    $(document).ready(() => {  
      $(".fa-desktop").addClass("active");
      $( ".fa-mobile" ).click(function() {
        $( ".fa-desktop" ).removeClass( "active" )
        $(".fa-mobile").addClass("active");
      });
      $( ".fa-desktop" ).click(function() {
        $(".fa-mobile").removeClass("active");
        $( ".fa-desktop" ).addClass( "active" )
      });
    });


  }

  customContactList() { 
    $(".custom-contact-list").slideToggle();
  }

  close(){ 
    $(".custom-contact-list").slideUp();
  }

  onAdd() {
    console.log(this.vareEditor.getHtml());
    console.log(this.vareEditor.getCss());

  }

  openCsvExport(content:any) {
    this.modalService.open(content, { windowClass: 'addCsvCustomerInformation' });
  }
  
  successUploadCampaigns(content:any) {
    this.modalService.open(content, { windowClass: 'successCampaignsModal' });
  }

  


}
